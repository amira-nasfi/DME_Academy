<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Non autorisé']);
    exit();
}

try {
    if ($_SESSION['role'] === 'doctor') {
        $appointments = getDoctorAppointments($_SESSION['user_id']);
    } else if ($_SESSION['role'] === 'patient') {
        $appointments = getPatientAppointments($_SESSION['user_id']);
    } else {
        http_response_code(403);
        echo json_encode(['error' => 'Accès refusé']);
        exit();
    }
    
    echo json_encode($appointments);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Erreur de base de données: ' . $e->getMessage()]);
}