<?php


session_start();
define('ACCESS_ALLOWED', true);
$root = $_SERVER['DOCUMENT_ROOT'].'/dme';
require_once $root.'/includes/auth.php';
require_once $root.'/includes/db.php';
require_once $root.'/includes/functions.php';

// Vérifier si l'utilisateur est un patient
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] != 'patient') {
    header('Location: /dme/login.php');
    exit();
}


$patient_id = $_SESSION['user_id'];

// Récupérer les dossiers médicaux du patient
$stmt = $pdo->prepare("SELECT mr.*, u.first_name AS doctor_first_name, u.last_name AS doctor_last_name 
                       FROM medical_records mr
                       JOIN users u ON mr.doctor_id = u.id
                       WHERE mr.patient_id = ? 
                       ORDER BY mr.record_date DESC");
$stmt->execute([$patient_id]);
$medical_records = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Récupérer les signes vitaux
$vitals_stmt = $pdo->prepare("SELECT * FROM vital_signs WHERE patient_id = ? ORDER BY date_recorded DESC");
$vitals_stmt->execute([$patient_id]);
$vital_signs = $vitals_stmt->fetchAll(PDO::FETCH_ASSOC);

$title = "Mon Dossier Médical";
include __DIR__ . '/../includes/header_footer.php';
?>
<link rel="stylesheet" href="../assets/css/style.css">

<div class="container">
    <h1 class="text-center my-4">Mon Dossier Médical</h1>

    <div class="row">
        <div class="col-md-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Historique Médical</h6>
                </div>
                <div class="card-body">
                    <?php if (empty($medical_records)): ?>
                        <p>Aucun dossier médical trouvé.</p>
                    <?php else: ?>
                        <div class="accordion" id="medicalRecordsAccordion">
                            <?php foreach ($medical_records as $record): ?>
                                <div class="card">
                                    <div class="card-header" id="heading<?= $record['id'] ?>">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapse<?= $record['id'] ?>" aria-expanded="true" aria-controls="collapse<?= $record['id'] ?>">
                                                <?= formatDate($record['record_date']) ?> - 
                                                <?= htmlspecialchars($record['record_type']) ?> 
                                                (Dr. <?= htmlspecialchars($record['doctor_first_name'] . ' ' . $record['doctor_last_name']) ?>)
                                            </button>
                                        </h2>
                                    </div>
                                    <div id="collapse<?= $record['id'] ?>" class="collapse" aria-labelledby="heading<?= $record['id'] ?>" data-parent="#medicalRecordsAccordion">
                                        <div class="card-body">
                                            <h5>Diagnostic</h5>
                                            <p><strong>Code:</strong> <?= htmlspecialchars($record['diagnosis_code']) ?></p>
                                            <p><strong>Description:</strong> <?= htmlspecialchars($record['diagnosis_description']) ?></p>

                                            <h5 class="mt-4">Traitement</h5>
                                            <p><?= htmlspecialchars($record['treatment']) ?></p>

                                            <?php if (!empty($record['notes'])): ?>
                                                <h5 class="mt-4">Notes</h5>
                                                <p><?= htmlspecialchars($record['notes']) ?></p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Signes Vitaux</h6>
                </div>
                <div class="card-body">
                    <?php if (empty($vital_signs)): ?>
                        <p>Aucune donnée de signes vitaux trouvée.</p>
                    <?php else: ?>
                        <div class="list-group">
                            <?php foreach ($vital_signs as $vital): ?>
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between">
                                        <strong><?= formatDateTime($vital['date_recorded']) ?></strong>
                                    </div>
                                    <div class="row mt-2">
                                        <div class="col-6">
                                            <small>Température: <?= $vital['temperature'] ? $vital['temperature'] . '°C' : 'N/A' ?></small>
                                        </div>
                                        <div class="col-6">
                                            <small>Pression art.: <?= $vital['blood_pressure'] ?: 'N/A' ?></small>
                                        </div>
                                        <div class="col-6">
                                            <small>Rythme cardiaque: <?= $vital['heart_rate'] ? $vital['heart_rate'] . ' bpm' : 'N/A' ?></small>
                                        </div>
                                        <div class="col-6">
                                            <small>Respiration: <?= $vital['respiratory_rate'] ? $vital['respiratory_rate'] . ' rpm' : 'N/A' ?></small>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Informations sur le patient -->
            <?php
            $patient_info = $pdo->prepare("SELECT u.*, p.insurance_number, p.blood_type, p.allergies 
                                          FROM users u
                                          LEFT JOIN patients p ON u.id = p.user_id
                                          WHERE u.id = ?");
            $patient_info->execute([$patient_id]);
            $patient = $patient_info->fetch(PDO::FETCH_ASSOC);
            ?>

            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Mes Informations</h6>
                </div>
                <div class="card-body">
                    <p><strong>Groupe sanguin:</strong> <?= $patient['blood_type'] ?: 'Non renseigné' ?></p>
                    <p><strong>Allergies:</strong> <?= $patient['allergies'] ?: 'Aucune connue' ?></p>
                    <p><strong>Numéro d'assurance:</strong> <?= $patient['insurance_number'] ?: 'Non renseigné' ?></p>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="<?= BASE_URL ?>/assets/js/script.js"></script>

<?php
echo show_footer();
?>