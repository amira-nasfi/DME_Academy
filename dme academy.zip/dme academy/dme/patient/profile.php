<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Vérifier si l'utilisateur est un patient
if ($_SESSION['user_type'] != 'patient') {
    header('Location: ../login.php');
    exit();
}

$patient_id = $_SESSION['user_id'];

// Récupérer les informations du patient
$stmt = $pdo->prepare("
    SELECT u.*, p.insurance_number, p.blood_type, p.allergies 
    FROM users u
    LEFT JOIN patients p ON u.id = p.user_id
    WHERE u.id = ?
");
$stmt->execute([$patient_id]);
$patient = $stmt->fetch(PDO::FETCH_ASSOC);

// Traitement du formulaire de mise à jour
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $date_of_birth = trim($_POST['date_of_birth']);
    $insurance_number = trim($_POST['insurance_number']);
    $blood_type = trim($_POST['blood_type']);
    $allergies = trim($_POST['allergies']);

    // Validation des données
    $errors = [];
    
    if (empty($first_name)) $errors[] = "Le prénom est requis.";
    if (empty($last_name)) $errors[] = "Le nom est requis.";
    if (empty($email)) $errors[] = "L'email est requis.";
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "L'email n'est pas valide.";
    
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            
            // Mettre à jour la table users
            $stmt = $pdo->prepare("
                UPDATE users 
                SET first_name = ?, last_name = ?, email = ?, phone = ?, address = ?, date_of_birth = ?
                WHERE id = ?
            ");
            $stmt->execute([$first_name, $last_name, $email, $phone, $address, $date_of_birth, $patient_id]);
            
            // Mettre à jour la table patients
            $stmt = $pdo->prepare("
                INSERT INTO patients (user_id, insurance_number, blood_type, allergies)
                VALUES (?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE 
                    insurance_number = VALUES(insurance_number),
                    blood_type = VALUES(blood_type),
                    allergies = VALUES(allergies)
            ");
            $stmt->execute([$patient_id, $insurance_number, $blood_type, $allergies]);
            
            $pdo->commit();
            
            $_SESSION['success'] = "Profil mis à jour avec succès.";
            header('Location: profile.php');
            exit();
        } catch (PDOException $e) {
            $pdo->rollBack();
            $errors[] = "Une erreur s'est produite lors de la mise à jour du profil: " . $e->getMessage();
        }
    }
}

$title = "Mon Profil";
include '../includes/header_footer.php';
?>
<link href="../assets/css/patient-profile.css" rel="stylesheet">

<div class="container">
    <h1 class="text-center my-4">Mon Profil</h1>
    
    <div class="row">
        <div class="col-md-8 mx-auto">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Informations personnelles</h6>
                </div>
                <div class="card-body">
                    <?php if (!empty($errors)): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php foreach ($errors as $error): ?>
                                    <li><?= htmlspecialchars($error) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php elseif (isset($_SESSION['success'])): ?>
                        <div class="alert alert-success">
                            <?= htmlspecialchars($_SESSION['success']) ?>
                        </div>
                        <?php unset($_SESSION['success']); ?>
                    <?php endif; ?>
                    
                    <form method="POST" action="profile.php">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="first_name">Prénom</label>
                                <input type="text" class="form-control" id="first_name" name="first_name" value="<?= htmlspecialchars($patient['first_name']) ?>" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="last_name">Nom</label>
                                <input type="text" class="form-control" id="last_name" name="last_name" value="<?= htmlspecialchars($patient['last_name']) ?>" required>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($patient['email']) ?>" required>
                        </div>
                        
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="phone">Téléphone</label>
                                <input type="text" class="form-control" id="phone" name="phone" value="<?= htmlspecialchars($patient['phone']) ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="date_of_birth">Date de naissance</label>
                                <input type="date" class="form-control" id="date_of_birth" name="date_of_birth" value="<?= htmlspecialchars($patient['date_of_birth']) ?>">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="address">Adresse</label>
                            <textarea class="form-control" id="address" name="address" rows="2"><?= htmlspecialchars($patient['address']) ?></textarea>
                        </div>
                        
                        <hr class="my-4">
                        
                        <h5 class="mb-3">Informations médicales</h5>
                        
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="insurance_number">Numéro d'assurance</label>
                                <input type="text" class="form-control" id="insurance_number" name="insurance_number" value="<?= htmlspecialchars($patient['insurance_number']) ?>">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="blood_type">Groupe sanguin</label>
                                <select class="form-control" id="blood_type" name="blood_type">
                                    <option value="">Sélectionner...</option>
                                    <option value="A+" <?= $patient['blood_type'] == 'A+' ? 'selected' : '' ?>>A+</option>
                                    <option value="A-" <?= $patient['blood_type'] == 'A-' ? 'selected' : '' ?>>A-</option>
                                    <option value="B+" <?= $patient['blood_type'] == 'B+' ? 'selected' : '' ?>>B+</option>
                                    <option value="B-" <?= $patient['blood_type'] == 'B-' ? 'selected' : '' ?>>B-</option>
                                    <option value="AB+" <?= $patient['blood_type'] == 'AB+' ? 'selected' : '' ?>>AB+</option>
                                    <option value="AB-" <?= $patient['blood_type'] == 'AB-' ? 'selected' : '' ?>>AB-</option>
                                    <option value="O+" <?= $patient['blood_type'] == 'O+' ? 'selected' : '' ?>>O+</option>
                                    <option value="O-" <?= $patient['blood_type'] == 'O-' ? 'selected' : '' ?>>O-</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="allergies">Allergies</label>
                            <textarea class="form-control" id="allergies" name="allergies" rows="2"><?= htmlspecialchars($patient['allergies']) ?></textarea>
                            <small class="form-text text-muted">Listez toutes vos allergies médicamenteuses ou alimentaires, séparées par des virgules.</small>
                        </div>
                        
                        <button type="submit" class="btn btn-primary">Mettre à jour</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="../assets/js/patient-profile.js"></script>

<?php
echo show_footer();
?>