<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Vérifier si l'utilisateur est un patient
if ($_SESSION['user_type'] != 'patient') {
    header('Location: ../login.php');
    exit();
}

if (!isset($_GET['id'])) {
    header('Location: appointments.php');
    exit();
}

$appointment_id = $_GET['id'];
$patient_id = $_SESSION['user_id'];

// Vérifier que le rendez-vous appartient bien au patient
$stmt = $pdo->prepare("SELECT * FROM appointments WHERE id = ? AND patient_id = ?");
$stmt->execute([$appointment_id, $patient_id]);
$appointment = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$appointment) {
    $_SESSION['error'] = "Rendez-vous introuvable ou vous n'avez pas la permission de l'annuler.";
    header('Location: appointments.php');
    exit();
}

// Vérifier que le rendez-vous n'est pas déjà annulé ou terminé
if ($appointment['status'] != 'scheduled') {
    $_SESSION['error'] = "Ce rendez-vous ne peut pas être annulé car il est déjà " . 
                         ($appointment['status'] == 'completed' ? 'terminé' : 'annulé');
    header('Location: appointments.php');
    exit();
}

// Annuler le rendez-vous
$stmt = $pdo->prepare("UPDATE appointments SET status = 'cancelled' WHERE id = ?");
if ($stmt->execute([$appointment_id])) {
    $_SESSION['success'] = "Le rendez-vous a été annulé avec succès.";
} else {
    $_SESSION['error'] = "Une erreur s'est produite lors de l'annulation du rendez-vous.";
}

header('Location: appointments.php');
exit();