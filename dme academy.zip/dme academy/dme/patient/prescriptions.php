<?php
// Autoriser l'accès au header_footer.php
define('ACCESS_ALLOWED', true);

require_once '../includes/auth.php';
require_once '../includes/db.php';

// Vérifier si l'utilisateur est un patient
if ($_SESSION['user_type'] !== 'patient') {
    header('Location: ../login.php');
    exit();
}

$patient_id = $_SESSION['user_id'];

// Récupérer les prescriptions du patient
$stmt = $pdo->prepare("
    SELECT p.*, u.first_name AS doctor_first_name, u.last_name AS doctor_last_name
    FROM prescriptions p
    JOIN users u ON p.doctor_id = u.id
    WHERE p.patient_id = ?
    ORDER BY p.start_date DESC
");
$stmt->execute([$patient_id]);
$prescriptions = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fonction pour formater la date
function formatDate($date) {
    return date('d/m/Y', strtotime($date));
}

// Fonction d'affichage du header
function show_header($title = "") {
    return "
    <!DOCTYPE html>
    <html lang='fr'>
    <head>
        <meta charset='UTF-8'>
        <title>$title</title>
        <link rel='stylesheet' href='../assets/css/style.css'>
        <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>
    </head>
    <body>
    ";
}

// Fonction d'affichage du footer
function show_footer() {
    return "
    <footer class='text-center mt-5 mb-3'>
        <p>&copy; " . date('Y') . " - Digital Medical Environment</p>
    </footer>
    </body>
    </html>
    ";
}

// Titre de la page
$title = "Mes Prescriptions";
echo show_header($title);
?>

<link href="../assets/css/style.css" rel="stylesheet">

<div class="container">
    <h1 class="text-center my-4">Mes Prescriptions</h1>

    <div class="card shadow mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Liste des prescriptions</h6>
        </div>
        <div class="card-body">
            <?php if (count($prescriptions) > 0): ?>
                <div class="table-responsive">
                    <table class="table table-bordered" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Médicament</th>
                                <th>Dosage</th>
                                <th>Fréquence</th>
                                <th>Date début</th>
                                <th>Date fin</th>
                                <th>Médecin</th>
                                <th>Instructions</th>
                                <th>Statut</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($prescriptions as $p): ?>
                                <tr>
                                    <td><?= htmlspecialchars($p['medication_name']) ?></td>
                                    <td><?= htmlspecialchars($p['dosage']) ?></td>
                                    <td><?= htmlspecialchars($p['frequency']) ?></td>
                                    <td><?= formatDate($p['start_date']) ?></td>
                                    <td><?= $p['end_date'] ? formatDate($p['end_date']) : '-' ?></td>
                                    <td>Dr. <?= htmlspecialchars($p['doctor_first_name'] . ' ' . $p['doctor_last_name']) ?></td>
                                    <td><?= nl2br(htmlspecialchars($p['instructions'])) ?></td>
                                    <td>
                                        <span class="badge badge-<?= 
                                            $p['status'] === 'active' ? 'primary' : 
                                            ($p['status'] === 'completed' ? 'success' : 'danger')
                                        ?>">
                                            <?= ucfirst($p['status']) ?>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p class="text-center">Aucune prescription trouvée.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script src="../assets/js/script.js"></script>

<?php
echo show_footer();
?>
