<?php
// patient/dashboard.php
define('BASE_URL', '/dme');
require_once __DIR__.'/../includes/config.php';
require_login();

// Vérifier que l'utilisateur est bien un patient
check_user_type('patient');

// Récupérer les informations du patient
$patient_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT u.*, p.* FROM users u JOIN patients p ON u.id = p.user_id WHERE u.id = ?");
$stmt->execute([$patient_id]);
$patient = $stmt->fetch(PDO::FETCH_ASSOC);

// Récupérer les dossiers médicaux
$stmt = $pdo->prepare("SELECT mr.*, u.first_name, u.last_name 
                      FROM medical_records mr 
                      JOIN users u ON mr.doctor_id = u.id 
                      WHERE mr.patient_id = ? 
                      ORDER BY mr.record_date DESC");
$stmt->execute([$patient_id]);
$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

$title = "Tableau de bord Patient";
include __DIR__.'/../includes/header_footer.php';
?>

<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">

<div class="dashboard-container">
    <header class="dashboard-header">
        <div class="header-left">
            <img src="<?= BASE_URL ?>/assets/images/logo.png" alt="Logo DME" class="logo-small">
            <h1>Tableau de bord Patient</h1>
        </div>
        <div class="header-right">
            <span class="welcome-message">Bonjour, <?= htmlspecialchars($patient['first_name']) ?></span>
            <a href="<?= BASE_URL ?>/logout.php" class="btn btn-logout">Déconnexion</a>
        </div>
    </header>
    
    <div class="dashboard-content">
        <aside class="sidebar">
            <nav>
                <ul>
                    <li class="active"><a href="<?= BASE_URL ?>/patient/dashboard.php">Accueil</a></li>
                    <li><a href="<?= BASE_URL ?>/patient/medical_records.php">Dossiers médicaux</a></li>
                    <li><a href="<?= BASE_URL ?>/patient/prescriptions.php">Ordonnances</a></li>
                    <li><a href="<?= BASE_URL ?>/patient/appointments.php">Rendez-vous</a></li>
                    <li><a href="<?= BASE_URL ?>/patient/profile.php">Profil</a></li>
                </ul>
            </nav>
        </aside>
        
        <main class="main-content">
            <div class="card summary-card">
                <h2>Résumé médical</h2>
                <div class="summary-grid">
                    <div class="summary-item">
                        <h3>Groupe sanguin</h3>
                        <p><?= htmlspecialchars($patient['blood_type'] ?? 'Non spécifié') ?></p>
                    </div>
                    <div class="summary-item">
                        <h3>Allergies</h3>
                        <p><?= $patient['allergies'] ? nl2br(htmlspecialchars($patient['allergies'])) : 'Aucune allergie connue' ?></p>
                    </div>
                    <div class="summary-item">
                        <h3>Dernière consultation</h3>
                        <p><?= !empty($records) ? date('d/m/Y', strtotime($records[0]['record_date'])) : 'Aucune consultation enregistrée' ?></p>
                    </div>
                </div>
            </div>
            
            <div class="card recent-records">
                <h2>Dossiers médicaux récents</h2>
                <?php if (empty($records)): ?>
                    <p>Aucun dossier médical disponible.</p>
                <?php else: ?>
                    <table class="records-table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Médecin</th>
                                <th>Diagnostic</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($records as $record): ?>
                                <tr>
                                    <td><?= date('d/m/Y', strtotime($record['record_date'])) ?></td>
                                    <td><?= htmlspecialchars(ucfirst($record['record_type'])) ?></td>
                                    <td>Dr. <?= htmlspecialchars($record['first_name'].' '.$record['last_name']) ?></td>
                                    <td><?= $record['diagnosis_description'] ? htmlspecialchars(substr($record['diagnosis_description'], 0, 50)).'...' : '--' ?></td>
                                    <td>
                                        <a href="<?= BASE_URL ?>/patient/medical_records.php" class="btn btn-view">Voir</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </main>
    </div>
</div>

<script src="<?= BASE_URL ?>/assets/js/script.js"></script>