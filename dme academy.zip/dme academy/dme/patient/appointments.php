<?php
define('ACCESS_ALLOWED', true);

require_once '../includes/auth.php';
require_once '../includes/db.php';
require_once '../includes/functions.php';

// Vérifier si l'utilisateur est un patient
if ($_SESSION['user_type'] != 'patient') {
    header('Location: ../login.php');
    exit();
}

$patient_id = $_SESSION['user_id'];

// Récupérer les rendez-vous du patient
$stmt = $pdo->prepare("
    SELECT a.*, u.first_name AS doctor_first_name, u.last_name AS doctor_last_name 
    FROM appointments a
    JOIN users u ON a.doctor_id = u.id
    WHERE a.patient_id = ?
    ORDER BY a.date DESC, a.time DESC
");
$stmt->execute([$patient_id]);
$appointments = $stmt->fetchAll(PDO::FETCH_ASSOC);

$title = "Mes Rendez-vous";
include '../includes/header_footer.php';
?>
<link href="../assets/css/style.css" rel="stylesheet">

<div class="container">
    <h1 class="text-center my-4">Mes Rendez-vous</h1>
    
    <div class="card shadow mb-4">
        <div class="card-header py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">Liste des rendez-vous</h6>
            <a href="create_appointment.php" class="btn btn-primary btn-sm">Prendre un rendez-vous</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="appointmentsTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Heure</th>
                            <th>Médecin</th>
                            <th>Motif</th>
                            <th>Statut</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($appointments as $appointment): ?>
                        <tr>
                            <td><?= formatDate($appointment['date']) ?></td>
                            <td><?= substr($appointment['time'], 0, 5) ?></td>
                            <td>Dr. <?= htmlspecialchars($appointment['doctor_first_name'] . ' ' . $appointment['doctor_last_name']) ?></td>
                            <td><?= htmlspecialchars($appointment['reason']) ?></td>
                            <td>
                                <span class="badge badge-<?= 
                                    $appointment['status'] == 'scheduled' ? 'primary' : 
                                    ($appointment['status'] == 'completed' ? 'success' : 'danger') 
                                ?>">
                                    <?= $appointment['status'] == 'scheduled' ? 'Planifié' : 
                                       ($appointment['status'] == 'completed' ? 'Terminé' : 'Annulé') ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($appointment['status'] == 'scheduled'): ?>
                                    <a href="cancel_appointment.php?id=<?= $appointment['id'] ?>" class="btn btn-sm btn-danger">Annuler</a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="../assets/js/script.js"></script>

<?php
echo show_footer();
?>