// Medical Records Page Specific JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Accordion functionality
    const accordionItems = document.querySelectorAll('.accordion-item');
    accordionItems.forEach(item => {
      const header = item.querySelector('.accordion-header');
      header.addEventListener('click', function() {
        const currentlyActive = document.querySelector('.accordion-item.active');
        if (currentlyActive && currentlyActive !== item) {
          currentlyActive.classList.remove('active');
          currentlyActive.querySelector('.accordion-collapse').classList.remove('show');
        }
        item.classList.toggle('active');
      });
    });
  
    // Vital signs chart
    if (document.getElementById('vitalSignsChart')) {
      const ctx = document.getElementById('vitalSignsChart').getContext('2d');
      const chart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: JSON.parse(document.getElementById('vitalSignsChart').dataset.labels),
          datasets: [
            {
              label: 'Pression artérielle (mmHg)',
              data: JSON.parse(document.getElementById('vitalSignsChart').dataset.bloodPressure),
              borderColor: '#e74a3b',
              backgroundColor: 'rgba(231, 74, 59, 0.1)',
              tension: 0.1
            },
            {
              label: 'Rythme cardiaque (bpm)',
              data: JSON.parse(document.getElementById('vitalSignsChart').dataset.heartRate),
              borderColor: '#4e73df',
              backgroundColor: 'rgba(78, 115, 223, 0.1)',
              tension: 0.1
            }
          ]
        },
        options: {
          responsive: true,
          plugins: {
            legend: {
              position: 'top',
            },
            tooltip: {
              mode: 'index',
              intersect: false,
            }
          },
          scales: {
            y: {
              beginAtZero: false
            }
          }
        }
      });
    }
  });