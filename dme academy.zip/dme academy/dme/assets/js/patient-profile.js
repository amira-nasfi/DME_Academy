// Profile Page Specific JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Form validation
    const profileForm = document.getElementById('profileForm');
    if (profileForm) {
      profileForm.addEventListener('submit', function(e) {
        let valid = true;
        
        // Validate required fields
        const requiredFields = profileForm.querySelectorAll('[required]');
        requiredFields.forEach(field => {
          if (!field.value.trim()) {
            field.classList.add('is-invalid');
            valid = false;
          } else {
            field.classList.remove('is-invalid');
          }
        });
  
        // Validate email format
        const emailField = profileForm.querySelector('#email');
        if (emailField && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailField.value)) {
          emailField.classList.add('is-invalid');
          valid = false;
        }
  
        if (!valid) {
          e.preventDefault();
          // Scroll to first invalid field
          const firstInvalid = profileForm.querySelector('.is-invalid');
          if (firstInvalid) {
            firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
            firstInvalid.focus();
          }
        }
      });
  
      // Real-time validation
      profileForm.querySelectorAll('input, textarea, select').forEach(field => {
        field.addEventListener('input', function() {
          if (this.hasAttribute('required') && !this.value.trim()) {
            this.classList.add('is-invalid');
          } else {
            this.classList.remove('is-invalid');
          }
  
          // Special validation for email
          if (this.id === 'email' && this.value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(this.value)) {
            this.classList.add('is-invalid');
          }
        });
      });
    }
  
    // Password toggle
    const passwordToggle = document.querySelector('.password-toggle');
    if (passwordToggle) {
      passwordToggle.addEventListener('click', function() {
        const passwordField = document.querySelector('#password');
        const icon = this.querySelector('i');
        
        if (passwordField.type === 'password') {
          passwordField.type = 'text';
          icon.classList.remove('fa-eye');
          icon.classList.add('fa-eye-slash');
        } else {
          passwordField.type = 'password';
          icon.classList.remove('fa-eye-slash');
          icon.classList.add('fa-eye');
        }
      });
    }
  });