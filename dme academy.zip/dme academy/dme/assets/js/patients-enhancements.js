``````````````/**
 * patients-enhancements.js
 */

document.addEventListener('DOMContentLoaded', function() {
    // 1. Recherche en temps réel avec debounce
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        let searchTimeout;
        
        searchInput.addEventListener('input', function() {
            clearTimeout(searchTimeout);
            searchTimeout = setTimeout(() => {
                const searchTerm = this.value.toLowerCase().trim();
                const rows = document.querySelectorAll('#patientsTable tbody tr');
                
                // Afficher l'indicateur de chargement
                const searchBtn = document.querySelector('.search-btn-enhanced');
                const originalContent = searchBtn.innerHTML;
                searchBtn.innerHTML = '<div class="loading-spinner"></div>';
                
                rows.forEach(row => {
                    const name = row.cells[0].textContent.toLowerCase();
                    const email = row.cells[1].textContent.toLowerCase();
                    const phone = row.cells[2].textContent.toLowerCase();
                    
                    const matches = name.includes(searchTerm) || 
                                   email.includes(searchTerm) || 
                                   phone.includes(searchTerm);
                    
                    row.style.display = matches ? '' : 'none';
                });
                
                // Restaurer le bouton
                setTimeout(() => {
                    searchBtn.innerHTML = originalContent;
                }, 300);
            }, 300);
        });

        // Gestion du bouton de recherche
        document.querySelector('.search-btn-enhanced').addEventListener('click', function() {
            searchInput.dispatchEvent(new Event('input'));
        });
    }

    // 2. Validation améliorée du formulaire
    const patientForm = document.getElementById('patientForm');
    if (patientForm) {
        // Validation en temps réel
        patientForm.querySelectorAll('input, select, textarea').forEach(field => {
            field.addEventListener('blur', function() {
                validateEnhancedField(this);
            });
        });

        // Validation à la soumission
        patientForm.addEventListener('submit', function(e) {
            let isValid = true;
            const requiredFields = this.querySelectorAll('[required]');
            
            requiredFields.forEach(field => {
                if (!validateEnhancedField(field)) {
                    isValid = false;
                }
            });

            if (!isValid) {
                e.preventDefault();
                showEnhancedToast('Veuillez corriger les erreurs dans le formulaire', 'error');
            } else {
                // Afficher l'indicateur de chargement sur le bouton
                const submitBtn = this.querySelector('button[type="submit"]');
                submitBtn.disabled = true;
                submitBtn.innerHTML = '<div class="loading-spinner"></div> Enregistrement...';
            }
        });
    }

    // 3. Fonction de validation améliorée
    function validateEnhancedField(field) {
        const value = field.value.trim();
        const wrapper = field.closest('.form-group-enhanced') || field.parentElement;
        
        // Supprimer les anciens messages d'erreur
        const existingError = wrapper.querySelector('.field-error');
        if (existingError) existingError.remove();
        
        // Réinitialiser le style
        field.classList.remove('field-error-border');
        
        // Validation des champs requis
        if (field.required && !value) {
            field.classList.add('field-error-border');
            const errorMsg = document.createElement('div');
            errorMsg.className = 'field-error';
            errorMsg.textContent = 'Ce champ est obligatoire';
            errorMsg.style.color = '#ef4444';
            errorMsg.style.fontSize = '0.75rem';
            errorMsg.style.marginTop = '0.25rem';
            wrapper.appendChild(errorMsg);
            return false;
        }
        
        // Validation spécifique pour l'email
        if (field.type === 'email' && value && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
            field.classList.add('field-error-border');
            const errorMsg = document.createElement('div');
            errorMsg.className = 'field-error';
            errorMsg.textContent = 'Veuillez entrer un email valide';
            errorMsg.style.color = '#ef4444';
            errorMsg.style.fontSize = '0.75rem';
            errorMsg.style.marginTop = '0.25rem';
            wrapper.appendChild(errorMsg);
            return false;
        }
        
        return true;
    }

    // 4. Affichage des messages toast
    function showEnhancedToast(message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `enhanced-toast toast-${type}`;
        
        // Icône selon le type
        const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';
        toast.innerHTML = `<i class="fas ${icon}"></i> ${message}`;
        
        // Style du toast
        toast.style.position = 'fixed';
        toast.style.bottom = '20px';
        toast.style.right = '20px';
        toast.style.padding = '12px 24px';
        toast.style.borderRadius = '6px';
        toast.style.color = 'white';
        toast.style.zIndex = '1000';
        toast.style.boxShadow = '0 4px 12px rgba(0,0,0,0.15)';
        toast.style.animation = 'fadeInUp 0.3s ease-out';
        toast.style.display = 'flex';
        toast.style.alignItems = 'center';
        toast.style.gap = '0.5rem';
        
        if (type === 'success') {
            toast.style.backgroundColor = '#10b981';
        } else {
            toast.style.backgroundColor = '#ef4444';
        }
        
        document.body.appendChild(toast);
        
        // Disparaît après 5 secondes
        setTimeout(() => {
            toast.style.animation = 'fadeOutDown 0.3s ease-out';
            setTimeout(() => toast.remove(), 300);
        }, 5000);
    }

    // 5. Animation pour les messages flash existants
    const flashMessages = document.querySelectorAll('.flash-message');
    flashMessages.forEach(msg => {
        msg.style.animation = 'fadeInUp 0.3s ease-out';
        
        setTimeout(() => {
            msg.style.opacity = '0';
            msg.style.transform = 'translateY(-10px)';
            setTimeout(() => msg.remove(), 300);
        }, 5000);
    });

    // 6. Gestion des transitions
    document.head.insertAdjacentHTML('beforeend', `
        <style>
            @keyframes fadeInUp {
                from { opacity: 0; transform: translateY(20px); }
                to { opacity: 1; transform: translateY(0); }
            }
            @keyframes fadeOutDown {
                from { opacity: 1; transform: translateY(0); }
                to { opacity: 0; transform: translateY(20px); }
            }
            .field-error-border {
                border-color: #ef4444 !important;
                box-shadow: 0 0 0 1px #ef4444;
            }
        </style>
    `);
});