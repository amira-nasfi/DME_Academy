// Fonctions utilitaires
document.addEventListener('DOMContentLoaded', function() {
    // Gestion des messages flash
    setTimeout(() => {
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            alert.style.transition = 'opacity 0.5s ease-out';
            alert.style.opacity = '0';
            setTimeout(() => alert.remove(), 500);
        });
    }, 5000);
    
    // Validation des formulaires
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            const requiredFields = form.querySelectorAll('[required]');
            let isValid = true;
            
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.style.borderColor = '#e74c3c';
                    isValid = false;
                } else {
                    field.style.borderColor = '#ddd';
                }
            });
            
            if (!isValid) {
                e.preventDefault();
                alert('Veuillez remplir tous les champs obligatoires.');
            }
        });
    });
    
    // Afficher/masquer le mot de passe
    const togglePassword = document.querySelector('.toggle-password');
    if (togglePassword) {
        togglePassword.addEventListener('click', function() {
            const passwordInput = document.querySelector('#password');
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.classList.toggle('fa-eye');
            this.classList.toggle('fa-eye-slash');
        });
    }
});

// Fonction pour afficher les erreurs
function showError(elementId, message) {
    const element = document.getElementById(elementId);
    if (element) {
        element.textContent = message;
        element.style.display = 'block';
    }
}

// Fonction pour masquer les erreurs
function hideError(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.style.display = 'none';
    }
}

// Validation en temps réel
function validateField(field, fieldName) {
    const value = field.value.trim();
    const errorId = `${fieldName}-error`;
    
    if (!value) {
        showError(errorId, 'Ce champ est obligatoire');
        return false;
    }
    
    // Validation spécifique pour l'email
    if (fieldName === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        showError(errorId, 'Veuillez entrer une adresse email valide');
        return false;
    }
    
    // Validation spécifique pour le mot de passe
    if (fieldName === 'password' && value.length < 8) {
        showError(errorId, 'Le mot de passe doit contenir au moins 8 caractères');
        return false;
    }
    
    hideError(errorId);
    return true;
}
document.addEventListener('DOMContentLoaded', function() {
    // Recherche en temps réel
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const filter = this.value.toLowerCase();
            const rows = document.querySelectorAll('#patientsTable tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filter) ? '' : 'none';
            });
        });
    }

    // Validation du formulaire
    const patientForm = document.getElementById('patientForm');
    if (patientForm) {
        patientForm.addEventListener('submit', function(e) {
            let valid = true;
            
            // Vérification des champs requis
            const requiredFields = this.querySelectorAll('[required]');
            requiredFields.forEach(field => {
                if (!field.value.trim()) {
                    field.style.borderColor = '#e74c3c';
                    valid = false;
                } else {
                    field.style.borderColor = '#ddd';
                }
            });

            // Validation email
            const emailField = this.querySelector('[type="email"]');
            if (emailField && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailField.value)) {
                emailField.style.borderColor = '#e74c3c';
                valid = false;
            }

            if (!valid) {
                e.preventDefault();
                alert('Veuillez remplir correctement tous les champs obligatoires.');
            }
        });
    }

    // Calcul de l'âge pour l'affichage
    function calculateAge(birthdate) {
        // Implémentation existante
    }
});
document.addEventListener('DOMContentLoaded', function() {
    // Initialisation du calendrier
    var calendarEl = document.getElementById('calendar');
    
    if (calendarEl) {
        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay'
            },
            events: function(fetchInfo, successCallback, failureCallback) {
                // Récupérer les rendez-vous via AJAX
                fetch('../api/get_appointments.php')
                    .then(response => response.json())
                    .then(data => {
                        const events = data.map(appointment => {
                            return {
                                title: appointment.patient_name || appointment.doctor_name,
                                start: appointment.date + 'T' + appointment.time,
                                extendedProps: {
                                    status: appointment.status,
                                    reason: appointment.reason
                                },
                                className: 'fc-event-' + appointment.status
                            };
                        });
                        successCallback(events);
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        failureCallback(error);
                    });
            },
            eventClick: function(info) {
                alert('Rendez-vous avec: ' + info.event.title + '\n' + 
                      'Statut: ' + info.event.extendedProps.status + '\n' +
                      'Motif: ' + info.event.extendedProps.reason);
            },
            locale: 'fr',
            firstDay: 1, // Lundi comme premier jour de la semaine
            buttonText: {
                today: 'Aujourd\'hui',
                month: 'Mois',
                week: 'Semaine',
                day: 'Jour'
            }
        });
        
        calendar.render();
    }
    
    // Validation des formulaires
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            let isValid = true;
            
            // Vérifier les champs requis
            form.querySelectorAll('[required]').forEach(field => {
                if (!field.value.trim()) {
                    field.style.borderColor = 'red';
                    isValid = false;
                } else {
                    field.style.borderColor = '#ddd';
                }
            });
            
            // Validation de la date
            const dateInput = form.querySelector('input[type="date"]');
            if (dateInput && new Date(dateInput.value) < new Date()) {
                alert('La date doit être dans le futur');
                dateInput.style.borderColor = 'red';
                isValid = false;
            }
            
            if (!isValid) {
                e.preventDefault();
                alert('Veuillez corriger les erreurs dans le formulaire.');
            }
        });
    });
});
class DoctorProfile {
    constructor() {
      this.form = document.getElementById('profileForm');
      this.init();
    }
  
    init() {
      if (this.form) {
        this.setupEventListeners();
        this.setupInputMasks();
        this.setupCharacterCounter();
      }
    }
  
    setupEventListeners() {
      // Real-time validation
      const validatedFields = ['first_name', 'last_name', 'email', 'phone', 'license_number'];
      validatedFields.forEach(field => {
        const element = document.getElementById(field);
        if (element) {
          element.addEventListener('blur', this.validateField.bind(this));
          element.addEventListener('input', this.clearValidation.bind(this));
        }
      });
  
      // Form submission
      this.form.addEventListener('submit', this.handleSubmit.bind(this));
    }
  
    setupInputMasks() {
      // Phone number formatting
      const phoneInput = document.getElementById('phone');
      if (phoneInput) {
        IMask(phoneInput, {
          mask: '+{7} (000) 000-00-00',
          lazy: false,
          overwrite: true,
          autofix: true
        }).on('accept', () => {
          this.validateField({ target: phoneInput });
        });
      }
    }
  
    setupCharacterCounter() {
      const bioField = document.getElementById('bio');
      if (!bioField) return;
  
      const maxLength = 500;
      const counter = document.getElementById('bio-counter');
  
      const updateCounter = () => {
        const remaining = maxLength - bioField.value.length;
        counter.textContent = `${remaining} caractères restants`;
        counter.style.color = remaining < 50 ? '#ef4444' : '#64748b';
      };
  
      bioField.addEventListener('input', updateCounter);
      updateCounter();
    }
  
    validateField(e) {
      const field = e.target;
      const value = field.value.trim();
      const fieldId = field.id;
  
      // Remove previous validation classes
      field.classList.remove('is-valid', 'is-invalid');
  
      // Skip validation if field is empty (except required fields)
      if (!value && !field.required) return true;
  
      // Field-specific validation
      let isValid = true;
      switch (fieldId) {
        case 'first_name':
        case 'last_name':
          isValid = /^[a-zA-ZÀ-ÿ\s\-]{2,50}$/.test(value);
          break;
        case 'email':
          isValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
          break;
        case 'phone':
          isValid = value === '' || /^\+?[\d\s\-]{10,20}$/.test(value.replace(/\D/g, ''));
          break;
        case 'license_number':
          isValid = /^[a-zA-Z0-9\-]{5,20}$/.test(value);
          break;
      }
  
      // Apply validation state
      if (isValid) {
        field.classList.add('is-valid');
      } else {
        field.classList.add('is-invalid');
      }
  
      return isValid;
    }
  
    clearValidation(e) {
      const field = e.target;
      field.classList.remove('is-valid', 'is-invalid');
    }
  
    validateForm() {
      let isValid = true;
      let firstInvalidField = null;
      const requiredFields = ['first_name', 'last_name', 'email', 'license_number'];
  
      requiredFields.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (field) {
          const event = { target: field };
          if (!this.validateField(event)) {
            isValid = false;
            if (!firstInvalidField) {
              firstInvalidField = field;
            }
          }
        }
      });
  
      // Scroll to first invalid field
      if (!isValid && firstInvalidField) {
        firstInvalidField.scrollIntoView({
          behavior: 'smooth',
          block: 'center'
        });
        firstInvalidField.focus();
      }
  
      return isValid;
    }
  
    async handleSubmit(e) {
      e.preventDefault();
  
      if (!this.validateForm()) {
        this.showToast('Veuillez corriger les erreurs dans le formulaire', 'error');
        return;
      }
  
      try {
        // Show loading state
        const submitBtn = this.form.querySelector('button[type="submit"]');
        submitBtn.classList.add('loading');
        submitBtn.disabled = true;
  
        // Prepare form data
        const formData = new FormData(this.form);
        const data = Object.fromEntries(formData.entries());
  
        // Simulate API call (replace with actual fetch)
        await new Promise(resolve => setTimeout(resolve, 1500));
  
        // Update preview with new data
        this.updatePreview(data);
  
        // Show success message
        this.showToast('Profil mis à jour avec succès', 'success');
  
      } catch (error) {
        console.error('Update error:', error);
        this.showToast('Une erreur est survenue lors de la mise à jour', 'error');
      } finally {
        const submitBtn = this.form.querySelector('button[type="submit"]');
        submitBtn.classList.remove('loading');
        submitBtn.disabled = false;
      }
    }
  
    updatePreview(data) {
      const previewFields = {
        'first_name': 'preview-fullname',
        'last_name': 'preview-fullname',
        'email': 'preview-email',
        'phone': 'preview-phone',
        'license_number': 'preview-license',
        'specialization': 'preview-specialization',
        'hospital_affiliation': 'preview-hospital',
        'bio': 'preview-bio'
      };
  
      // Update full name separately
      if (data.first_name || data.last_name) {
        const fullName = `${data.first_name || ''} ${data.last_name || ''}`.trim();
        document.getElementById('preview-fullname').textContent = fullName || 'Non renseigné';
      }
  
      // Update other fields
      Object.entries(previewFields).forEach(([field, previewId]) => {
        if (field !== 'first_name' && field !== 'last_name') {
          const element = document.getElementById(previewId);
          if (element) {
            element.textContent = data[field] || (field === 'bio' ? 'Aucune biographie renseignée' : 'Non renseigné');
            if (field === 'bio') {
              element.innerHTML = data[field] ? data[field].replace(/\n/g, '<br>') : 'Aucune biographie renseignée';
            }
          }
        }
      });
    }
  
    showToast(message, type = 'success') {
      const toastContainer = document.getElementById('toast-container') || this.createToastContainer();
      const toast = document.createElement('div');
      
      toast.className = `toast toast-${type} animate-fade-in`;
      toast.innerHTML = `
        <span>${message}</span>
        <button class="toast-close">&times;</button>
      `;
      
      toast.querySelector('.toast-close').addEventListener('click', () => {
        toast.remove();
      });
      
      toastContainer.appendChild(toast);
      
      // Auto-remove after 5 seconds
      setTimeout(() => {
        toast.classList.add('animate-fade-out');
        setTimeout(() => toast.remove(), 300);
      }, 5000);
    }
  
    createToastContainer() {
      const container = document.createElement('div');
      container.id = 'toast-container';
      container.className = 'fixed bottom-4 right-4 space-y-2 z-50';
      document.body.appendChild(container);
      return container;
    }
  }
  
  // Initialize when DOM is loaded
  document.addEventListener('DOMContentLoaded', () => {
    new DoctorProfile();
    
    // Add animation to cards
    const cards = document.querySelectorAll('.profile-card');
    cards.forEach((card, index) => {
      card.style.animationDelay = `${index * 0.1}s`;
      card.classList.add('animate-fade-in');
    });
  });
  document.addEventListener('DOMContentLoaded', function() {
    // Initialisation des tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
      return new bootstrap.Tooltip(tooltipTriggerEl);
    });
  
    // Gestion des onglets
    const tabLinks = document.querySelectorAll('.nav-tabs .nav-link');
    tabLinks.forEach(link => {
      link.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Supprimer la classe active de tous les onglets
        tabLinks.forEach(tab => {
          tab.classList.remove('active');
        });
        
        // Ajouter la classe active à l'onglet cliqué
        this.classList.add('active');
        
        // Masquer tous les contenus d'onglets
        const tabContents = document.querySelectorAll('.tab-content .tab-pane');
        tabContents.forEach(content => {
          content.classList.remove('show', 'active');
        });
        
        // Afficher le contenu de l'onglet sélectionné
        const target = this.getAttribute('href');
        document.querySelector(target).classList.add('show', 'active');
      });
    });
  
    // Confirmation pour les actions sensibles
    const deleteButtons = document.querySelectorAll('.btn-danger, .delete-btn');
    deleteButtons.forEach(button => {
      button.addEventListener('click', function(e) {
        if (!confirm('Êtes-vous sûr de vouloir effectuer cette action ?')) {
          e.preventDefault();
        }
      });
    });
  
    // Gestion des formulaires modaux
    const modalForms = document.querySelectorAll('.modal-form');
    modalForms.forEach(form => {
      form.addEventListener('submit', async function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        const submitBtn = this.querySelector('button[type="submit"]');
        const originalText = submitBtn.textContent;
        
        // Afficher un indicateur de chargement
        submitBtn.disabled = true;
        submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Traitement...';
        
        try {
          const response = await fetch(this.action, {
            method: this.method,
            body: formData
          });
          
          const result = await response.json();
          
          if (result.success) {
            // Afficher un message de succès
            showAlert('success', result.message || 'Opération réussie');
            
            // Recharger la page ou mettre à jour le contenu si nécessaire
            if (result.redirect) {
              window.location.href = result.redirect;
            } else if (result.update) {
              // Logique de mise à jour du DOM
            }
          } else {
            // Afficher un message d'erreur
            showAlert('danger', result.message || 'Une erreur est survenue');
          }
        } catch (error) {
          console.error('Error:', error);
          showAlert('danger', 'Une erreur réseau est survenue');
        } finally {
          submitBtn.disabled = false;
          submitBtn.textContent = originalText;
        }
      });
    });
  
    // Fonction pour afficher des alertes
    function showAlert(type, message) {
      const alertDiv = document.createElement('div');
      alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
      alertDiv.role = 'alert';
      alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
      `;
      
      const alertsContainer = document.querySelector('.alerts-container') || document.body;
      alertsContainer.prepend(alertDiv);
      
      // Supprimer automatiquement l'alerte après 5 secondes
      setTimeout(() => {
        alertDiv.classList.remove('show');
        setTimeout(() => alertDiv.remove(), 150);
      }, 5000);
    }
  
    // Fonction pour charger dynamiquement des données
    function loadData(url, containerId, params = {}) {
      const container = document.getElementById(containerId);
      if (!container) return;
      
      container.innerHTML = '<div class="text-center py-4"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Chargement...</span></div></div>';
      
      const queryString = new URLSearchParams(params).toString();
      const fullUrl = queryString ? `${url}?${queryString}` : url;
      
      fetch(fullUrl)
        .then(response => response.text())
        .then(html => {
          container.innerHTML = html;
          // Initialiser les composants dans le contenu chargé
          initComponents(container);
        })
        .catch(error => {
          console.error('Error:', error);
          container.innerHTML = '<div class="alert alert-danger">Erreur lors du chargement des données</div>';
        });
    }
  
    // Initialiser les composants dans une zone spécifique
    function initComponents(scope = document) {
      // Initialiser les tooltips
      const tooltips = scope.querySelectorAll('[data-bs-toggle="tooltip"]');
      tooltips.forEach(el => new bootstrap.Tooltip(el));
      
      // Initialiser les popovers
      const popovers = scope.querySelectorAll('[data-bs-toggle="popover"]');
      popovers.forEach(el => new bootstrap.Popover(el));
    }
  
    // Gestion des filtres et recherche
    const searchForms = document.querySelectorAll('.search-form, .filter-form');
    searchForms.forEach(form => {
      form.addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        const params = {};
        formData.forEach((value, key) => {
          if (value) params[key] = value;
        });
        
        const target = this.dataset.target;
        if (target) {
          loadData(this.action, target, params);
        } else {
          // Rediriger avec les paramètres de recherche
          const queryString = new URLSearchParams(params).toString();
          window.location.href = `${this.action}?${queryString}`;
        }
      });
      
      // Réinitialiser les filtres
      const resetBtn = form.querySelector('.reset-btn');
      if (resetBtn) {
        resetBtn.addEventListener('click', () => {
          form.reset();
          form.dispatchEvent(new Event('submit'));
        });
      }
    });
  
    // Gestion des dates
    const datePickers = document.querySelectorAll('.datepicker');
    datePickers.forEach(input => {
      new Datepicker(input, {
        format: 'dd/mm/yyyy',
        autohide: true,
        language: 'fr'
      });
    });
  
    // Fonction pour exporter des données
    window.exportData = function(format, url) {
      // Implémentation de l'export selon le format (Excel, PDF, etc.)
      console.log(`Exporting data to ${format} from ${url}`);
      // Ici, vous pourriez utiliser une bibliothèque comme jsPDF ou SheetJS
      // Ou faire une requête vers un endpoint backend qui génère le fichier
    };
  
    // Initialiser les composants au chargement
    initComponents();
  });
  
  // Fonctions utilitaires
  function formatDate(dateString) {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR');
  }
  
  function formatDateTime(dateTimeString) {
    if (!dateTimeString) return '';
    const date = new Date(dateTimeString);
    return date.toLocaleString('fr-FR');
  }



