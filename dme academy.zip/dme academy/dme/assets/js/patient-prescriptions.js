// Prescriptions Page Specific JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize DataTable
    if (document.getElementById('prescriptionsTable')) {
      $('#prescriptionsTable').DataTable({
        language: {
          url: '//cdn.datatables.net/plug-ins/1.13.4/i18n/fr-FR.json'
        },
        order: [[0, 'desc']],
        responsive: true,
        columns: [
          null, // Date
          null, // Doctor
          null, // Medication
          null, // Dosage
          null, // Frequency
          null, // Period
          { orderable: false } // Status
        ]
      });
    }
  
    // Prescription details modal
    const prescriptionDetails = document.querySelectorAll('.prescription-details');
    prescriptionDetails.forEach(detail => {
      detail.addEventListener('click', function(e) {
        e.preventDefault();
        const modal = new bootstrap.Modal(document.getElementById('prescriptionModal'));
        const modalTitle = document.getElementById('prescriptionModalLabel');
        const modalBody = document.getElementById('prescriptionModalBody');
  
        fetch(this.href)
          .then(response => response.json())
          .then(data => {
            modalTitle.textContent = `Détails: ${data.medication_name}`;
            modalBody.innerHTML = `
              <p><strong>Dosage:</strong> ${data.dosage}</p>
              <p><strong>Fréquence:</strong> ${data.frequency}</p>
              <p><strong>Période:</strong> ${data.start_date} - ${data.end_date || 'En cours'}</p>
              <p><strong>Statut:</strong> <span class="badge bg-${data.status === 'active' ? 'success' : data.status === 'expired' ? 'secondary' : 'danger'}">${data.status === 'active' ? 'Active' : data.status === 'expired' ? 'Terminée' : 'Annulée'}</span></p>
              <div class="card mt-3">
                <div class="card-header">Instructions</div>
                <div class="card-body">
                  ${data.instructions || 'Aucune instruction spécifique.'}
                </div>
              </div>
            `;
            modal.show();
          });
      });
    });
  });