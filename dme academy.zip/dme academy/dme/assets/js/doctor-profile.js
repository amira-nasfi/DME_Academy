class DoctorProfile {
    constructor() {
        this.form = document.getElementById('profileForm');
        this.toastContainer = document.getElementById('toast-container');
        this.init();
    }

    init() {
        if (!this.form) return;

        this.setupEventListeners();
        this.setupInputMasks();
        this.setupCharacterCounter();
        this.setupToastContainer();
        this.equalizeCardHeights();
    }

    setupEventListeners() {
        // Validation en temps réel
        ['first_name', 'last_name', 'email', 'phone', 'license_number'].forEach(field => {
            const el = document.getElementById(field);
            if (el) {
                el.addEventListener('blur', () => this.validateField(el));
                el.addEventListener('input', () => this.clearValidation(el));
            }
        });

        // Soumission du formulaire
        this.form.addEventListener('submit', (e) => this.handleSubmit(e));
    }

    setupInputMasks() {
        // Masque pour le téléphone
        const phoneInput = document.getElementById('phone');
        if (phoneInput) {
            IMask(phoneInput, {
                mask: '+{7} (000) 000-00-00',
                lazy: false,
                overwrite: true
            }).on('accept', () => {
                this.validateField(phoneInput);
            });
        }
    }

    setupCharacterCounter() {
        const bioField = document.getElementById('bio');
        if (!bioField) return;

        const maxLength = 1000;
        const counter = document.getElementById('bio-counter');

        const updateCounter = () => {
            const remaining = maxLength - bioField.value.length;
            counter.textContent = `${remaining} caractères restants`;
            counter.style.color = remaining < (maxLength * 0.1) ? 'var(--error)' : 'var(--gray)';
        };

        bioField.addEventListener('input', updateCounter);
        updateCounter();
    }

    setupToastContainer() {
        if (!this.toastContainer) {
            this.toastContainer = document.createElement('div');
            this.toastContainer.id = 'toast-container';
            this.toastContainer.className = 'toast-container';
            document.body.appendChild(this.toastContainer);
        }
    }

    equalizeCardHeights() {
        const formCol = document.querySelector('.form-column');
        const previewCol = document.querySelector('.preview-column');
        
        if (formCol && previewCol) {
            const formHeight = formCol.offsetHeight;
            const previewHeight = previewCol.offsetHeight;
            const maxHeight = Math.max(formHeight, previewHeight);
            
            formCol.style.minHeight = `${maxHeight}px`;
            previewCol.style.minHeight = `${maxHeight}px`;
        }
    }

    validateField(field) {
        const value = field.value.trim();
        const fieldId = field.id;

        // Reset des états
        field.classList.remove('is-valid', 'is-invalid');

        // Validation conditionnelle
        let isValid = true;
        const patterns = {
            first_name: /^[a-zA-ZÀ-ÿ\s\-]{2,50}$/,
            last_name: /^[a-zA-ZÀ-ÿ\s\-]{2,50}$/,
            email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
            phone: /^\+?[\d\s\-]{10,20}$/,
            license_number: /^[a-zA-Z0-9\-]{5,20}$/
        };

        if (field.required || value) {
            isValid = patterns[fieldId].test(value);
            field.classList.add(isValid ? 'is-valid' : 'is-invalid');
        }

        return isValid;
    }

    clearValidation(field) {
        field.classList.remove('is-valid', 'is-invalid');
    }

    validateForm() {
        let isValid = true;
        let firstInvalidField = null;
        const requiredFields = ['first_name', 'last_name', 'email', 'license_number'];

        requiredFields.forEach(fieldId => {
            const field = document.getElementById(fieldId);
            if (field && !this.validateField(field)) {
                isValid = false;
                if (!firstInvalidField) {
                    firstInvalidField = field;
                }
            }
        });

        // Scroll vers le premier champ invalide
        if (!isValid && firstInvalidField) {
            firstInvalidField.scrollIntoView({
                behavior: 'smooth',
                block: 'center'
            });
            firstInvalidField.focus();
        }

        return isValid;
    }

    async handleSubmit(e) {
        e.preventDefault();

        if (!this.validateForm()) {
            this.showToast('Veuillez corriger les erreurs dans le formulaire', 'error');
            return;
        }

        const submitBtn = this.form.querySelector('button[type="submit"]');
        try {
            // État de chargement
            submitBtn.disabled = true;
            submitBtn.classList.add('loading');
            
            // Simulation d'envoi (remplacer par fetch() en production)
            await new Promise(resolve => setTimeout(resolve, 1500));

            // Succès
            this.showToast('Profil mis à jour avec succès', 'success');
            this.updatePreview();

        } catch (error) {
            console.error('Erreur:', error);
            this.showToast('Une erreur est survenue', 'error');
        } finally {
            submitBtn.disabled = false;
            submitBtn.classList.remove('loading');
        }
    }

    updatePreview() {
        const formData = new FormData(this.form);
        
        // Mise à jour des valeurs
        document.getElementById('preview-fullname').textContent = 
            `${formData.get('first_name')} ${formData.get('last_name')}`.trim() || 'Non renseigné';
        
        document.getElementById('preview-email').textContent = 
            formData.get('email') || 'Non renseigné';
        
        document.getElementById('preview-phone').textContent = 
            formData.get('phone') || 'Non renseigné';
        
        document.getElementById('preview-license').textContent = 
            formData.get('license_number') || 'Non renseigné';
        
        document.getElementById('preview-specialization').textContent = 
            formData.get('specialization') || 'Non renseignée';
        
        document.getElementById('preview-hospital').textContent = 
            formData.get('hospital_affiliation') || 'Non renseigné';
        
        const bioContent = formData.get('bio');
        document.getElementById('preview-bio').innerHTML = 
            bioContent ? bioContent.replace(/\n/g, '<br>') : 'Aucune biographie renseignée';
    }

    showToast(message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <span>${message}</span>
            <button class="toast-close">&times;</button>
        `;

        toast.querySelector('.toast-close').addEventListener('click', () => {
            toast.remove();
        });

        this.toastContainer.appendChild(toast);

        // Suppression automatique
        setTimeout(() => {
            toast.classList.add('fade-out');
            setTimeout(() => toast.remove(), 300);
        }, 5000);
    }
}

// Initialisation
document.addEventListener('DOMContentLoaded', () => {
    new DoctorProfile();
});