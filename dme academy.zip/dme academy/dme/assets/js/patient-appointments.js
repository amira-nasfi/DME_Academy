// Appointments Page Specific JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Initialize DataTable
    if (document.getElementById('appointmentsTable')) {
      $('#appointmentsTable').DataTable({
        language: {
          url: '//cdn.datatables.net/plug-ins/1.13.4/i18n/fr-FR.json'
        },
        order: [[0, 'desc']],
        responsive: true,
        columnDefs: [
          { responsivePriority: 1, targets: 0 }, // Date
          { responsivePriority: 2, targets: 2 }, // Doctor
          { responsivePriority: 3, targets: 3 }, // Reason
          { responsivePriority: 4, targets: 4 }, // Status
          { responsivePriority: 5, targets: 5 }, // Actions
          { responsivePriority: 6, targets: 1 }  // Time
        ]
      });
    }
  
    // Enhanced cancel confirmation
    const cancelButtons = document.querySelectorAll('.cancel-appointment');
    cancelButtons.forEach(button => {
      button.addEventListener('click', function(e) {
        e.preventDefault();
        Swal.fire({
          title: 'Confirmer l\'annulation',
          text: "Êtes-vous sûr de vouloir annuler ce rendez-vous?",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Oui, annuler',
          cancelButtonText: 'Non'
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.href = this.href;
          }
        });
      });
    });
  });