<?php
// login.php
require_once 'includes/config.php';
require_once 'includes/functions.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Rediriger si déjà connecté
if (is_logged_in()) {
    redirect_to_dashboard();
}

// Initialisation des variables
$error = null;
$user = null;

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username']);
    $password = sanitize($_POST['password']);
    
    try {
        // Recherche de l'utilisateur
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ? LIMIT 1");
        $stmt->execute([$username, $username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        // Vérification du mot de passe
        if ($user) {
            // Version avec PEPPER (si utilisé dans signup.php)
            $password_to_verify = defined('PEPPER') ? $password . PEPPER : $password;
            
            if (password_verify($password_to_verify, $user['password'])) {
                if (!$user['is_active']) {
                    $error = "Compte désactivé";
                } else {
                    // Mise à jour de la session
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['user_type'] = $user['user_type'];
                    $_SESSION['last_activity'] = time();
                    
                    // Mise à jour du dernier login
                    $pdo->prepare("UPDATE users SET last_login = NOW() WHERE id = ?")->execute([$user['id']]);
                    
                    // Journalisation
                    if (function_exists('log_audit')) {
                        log_audit($user['id'], 'login', 'users', $user['id'], null, null);
                    }
                    
                    // DEBUG: Affiche le hash stocké vs hash calculé
                    error_log("DB Hash: " . $user['password']);
                    error_log("Input Hash: " . password_hash($password_to_verify, PASSWORD_BCRYPT));
                    
                    // Redirection vers page d’accueil animée
                    header('Location: welcome.php');
                    exit();
                }
            } else {
                $error = "Mot de passe incorrect";
                // DEBUG
                error_log("Échec connexion pour: " . $username);
            }
        } else {
            $error = "Utilisateur non trouvé";
        }
    } catch (PDOException $e) {
        $error = "Erreur de connexion: " . $e->getMessage();
    }
}

function redirect_to_dashboard() {
    if (!isset($_SESSION['user_type'])) {
        header('Location: login.php');
        exit();
    }
    
    if ($_SESSION['user_type'] === 'doctor') {
        header('Location: doctor/dashboard.php');
    } else {
        header('Location: patient/dashboard.php');
    }
    exit();
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        /* Styles temporaires pour debug */
        .debug-info {
            background: #f8f9fa;
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
            font-family: monospace;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <img src="assets/images/logo.png" alt="Logo DME" class="logo">
            <h1>Dossier Médical Électronique</h1>
            <p>Conformité HL7 et HIPAA</p>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        
        <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
            <div class="debug-info">
                <strong>DEBUG:</strong><br>
                Username: <?= htmlspecialchars($_POST['username'] ?? '') ?><br>
                User found: <?= isset($user) ? 'Yes' : 'No' ?><br>
                PEPPER defined: <?= defined('PEPPER') ? 'Yes' : 'No' ?><br>
                <?php if (isset($user)): ?>
                User active: <?= $user['is_active'] ? 'Yes' : 'No' ?>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        
        <form action="login.php" method="POST" class="login-form">
            <div class="form-group">
                <label for="username">Nom d'utilisateur ou Email</label>
                <input type="text" id="username" name="username" required>
            </div>
            
            <div class="form-group">
                <label for="password">Mot de passe</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Se connecter</button>
                <a href="forgot-password.php" class="forgot-password">Mot de passe oublié?</a>
            </div>
        </form>
        
        <div class="login-footer">
            <p>Nouveau sur DME? <a href="signup.php">Créer un compte</a></p>
        </div>
    </div>
    
    <script src="assets/js/script.js"></script>
</body>
</html>
