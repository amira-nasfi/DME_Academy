<?php
// welcome.php
require_once 'includes/config.php';
require_login();

$user_type = $_SESSION['user_type']; // "doctor" ou "patient"
$username = htmlspecialchars($_SESSION['username']);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Bienvenue - DME Academy</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="assets/css/style.css">
  <style>
    body {
      background: linear-gradient(to right, #3f87a6, #ebf8e1, #f69d3c);
      font-family: 'Segoe UI', sans-serif;
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
    }

    .welcome-card {
      background: white;
      padding: 40px;
      border-radius: 20px;
      box-shadow: 0 8px 30px rgba(0, 0, 0, 0.1);
      text-align: center;
      max-width: 600px;
      animation: slideIn 1s ease forwards;
      opacity: 0;
    }

    @keyframes slideIn {
      from {
        transform: translateY(50px);
        opacity: 0;
      }
      to {
        transform: translateY(0);
        opacity: 1;
      }
    }

    .welcome-card h2 {
      font-size: 2em;
      color: #333;
    }

    .welcome-card p {
      margin-top: 10px;
      color: #555;
      line-height: 1.6;
    }

    .btn-start {
      margin-top: 30px;
      padding: 12px 24px;
      background-color: #007bff;
      color: white;
      border: none;
      border-radius: 25px;
      font-size: 16px;
      cursor: pointer;
      transition: background-color 0.3s ease, transform 0.3s ease;
    }

    .btn-start:hover {
      background-color: #0056b3;
      transform: scale(1.05);
    }

    .logo {
      width: 100px;
      margin-bottom: 20px;
    }
  </style>
</head>
<body>
  <div class="welcome-card">
    <img src="assets/images/logo.png" alt="Logo DME" class="logo">
    <h2>Bienvenue <?= $username ?> !</h2>
    <p><strong>DME Academy</strong> est un système moderne et sécurisé pour la gestion des dossiers médicaux électroniques.</p>
    <p>Nous sommes ravis de vous compter parmi nous. Cliquez sur "Commencer" pour accéder à votre tableau de bord.</p>
    <button class="btn-start" onclick="redirectToDashboard()">Commencer</button>
  </div>

  <script>
    function redirectToDashboard() {
      const userType = "<?= $user_type ?>";
      if (userType === "doctor") {
        window.location.href = "doctor/dashboard.php";
      } else if (userType === "patient") {
        window.location.href = "patient/dashboard.php";
      } else {
        alert("Type d'utilisateur non reconnu.");
      }
    }
  </script>
</body>
</html>
