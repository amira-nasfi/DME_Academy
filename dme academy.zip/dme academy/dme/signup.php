<?php
// signup.php
require_once 'includes/config.php';
require_once __DIR__ . '/includes/functions.php'; // AJOUTEZ CETTE LIGNE

// Rediriger si déjà connecté
if (is_logged_in()) {
    redirect_to_dashboard();
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize($_POST['username']);
    $email = sanitize($_POST['email']);
    $password = sanitize($_POST['password']);
    $confirm_password = sanitize($_POST['confirm_password']);
    $user_type = sanitize($_POST['user_type']);
    $first_name = sanitize($_POST['first_name']);
    $last_name = sanitize($_POST['last_name']);
    
    // Validation
    $errors = [];
    
    if (empty($username)) $errors[] = "Le nom d'utilisateur est obligatoire";
    if (empty($email)) $errors[] = "L'email est obligatoire";
    if (empty($password)) $errors[] = "Le mot de passe est obligatoire";
    if ($password !== $confirm_password) $errors[] = "Les mots de passe ne correspondent pas";
    if (!in_array($user_type, ['patient', 'doctor'])) $errors[] = "Type d'utilisateur invalide";
    
    // Vérifier si l'utilisateur existe déjà
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    if ($stmt->fetch()) $errors[] = "Le nom d'utilisateur ou l'email est déjà utilisé";
    
    if (empty($errors)) {
        try {
            // Génération du code de vérification
            $verification_code = bin2hex(random_bytes(16));
            
            // Hash du mot de passe
            $password_hash = password_hash($password . PEPPER, PASSWORD_BCRYPT);
            
            // Insertion de l'utilisateur
            $stmt = $pdo->prepare("INSERT INTO users (username, email, password, user_type, first_name, last_name, verification_code) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$username, $email, $password_hash, $user_type, $first_name, $last_name, $verification_code]);
            $user_id = $pdo->lastInsertId();
            
            // Insertion dans la table spécifique (patient ou doctor)
            if ($user_type === 'doctor') {
                $license_number = sanitize($_POST['license_number']);
                $stmt = $pdo->prepare("INSERT INTO doctors (user_id, license_number) VALUES (?, ?)");
                $stmt->execute([$user_id, $license_number]);
            } else {
                $stmt = $pdo->prepare("INSERT INTO patients (user_id) VALUES (?)");
                $stmt->execute([$user_id]);
            }
            
            // Journalisation
            log_audit($user_id, 'signup', 'users', $user_id, null, null);
            
            // Envoyer un email de vérification (à implémenter)
            // send_verification_email($email, $verification_code);
            
            // Message de succès
            $_SESSION['success_message'] = "Inscription réussie! Veuillez vérifier votre email pour activer votre compte.";
            header('Location: login.php');
            exit();
        } catch (PDOException $e) {
            $errors[] = "Erreur lors de l'inscription: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <img src="assets/images/logo.png" alt="Logo DME" class="logo">
            <h1>Créer un compte</h1>
            <p>Rejoignez notre système DME sécurisé</p>
        </div>
        
        <?php if (!empty($errors)): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= $error ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <form action="signup.php" method="POST" class="login-form" id="signupForm">
            <div class="form-group">
                <label for="user_type">Je suis un</label>
                <select id="user_type" name="user_type" required>
                    <option value="">-- Sélectionnez --</option>
                    <option value="patient" <?= isset($_POST['user_type']) && $_POST['user_type'] === 'patient' ? 'selected' : '' ?>>Patient</option>
                    <option value="doctor" <?= isset($_POST['user_type']) && $_POST['user_type'] === 'doctor' ? 'selected' : '' ?>>Médecin</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="first_name">Prénom</label>
                <input type="text" id="first_name" name="first_name" value="<?= isset($_POST['first_name']) ? $_POST['first_name'] : '' ?>" required>
            </div>
            
            <div class="form-group">
                <label for="last_name">Nom</label>
                <input type="text" id="last_name" name="last_name" value="<?= isset($_POST['last_name']) ? $_POST['last_name'] : '' ?>" required>
            </div>
            
            <div class="form-group">
                <label for="username">Nom d'utilisateur</label>
                <input type="text" id="username" name="username" value="<?= isset($_POST['username']) ? $_POST['username'] : '' ?>" required>
                <small id="username-error" class="error-message"></small>
            </div>
            
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" value="<?= isset($_POST['email']) ? $_POST['email'] : '' ?>" required>
                <small id="email-error" class="error-message"></small>
            </div>
            
            <div class="form-group">
                <label for="password">Mot de passe</label>
                <input type="password" id="password" name="password" required>
                <small id="password-error" class="error-message"></small>
            </div>
            
            <div class="form-group">
                <label for="confirm_password">Confirmer le mot de passe</label>
                <input type="password" id="confirm_password" name="confirm_password" required>
                <small id="confirm_password-error" class="error-message"></small>
            </div>
            
            <div id="doctor-fields" style="display: none;">
                <div class="form-group">
                    <label for="license_number">Numéro de licence médicale</label>
                    <input type="text" id="license_number" name="license_number" value="<?= isset($_POST['license_number']) ? $_POST['license_number'] : '' ?>">
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">S'inscrire</button>
            </div>
        </form>
        
        <div class="login-footer">
            <p>Déjà inscrit? <a href="login.php">Connectez-vous ici</a></p>
        </div>
    </div>
    
    <script src="assets/js/script.js"></script>
    <script>
        // Afficher/masquer les champs spécifiques aux médecins
        document.getElementById('user_type').addEventListener('change', function() {
            const doctorFields = document.getElementById('doctor-fields');
            doctorFields.style.display = this.value === 'doctor' ? 'block' : 'none';
        });
        
        // Déclencher l'événement change au chargement si nécessaire
        const userType = document.getElementById('user_type');
        if (userType.value === 'doctor') {
            document.getElementById('doctor-fields').style.display = 'block';
        }
        
        // Validation en temps réel
        document.getElementById('signupForm').addEventListener('input', function(e) {
            const field = e.target;
            const fieldName = field.name;
            
            if (fieldName === 'username' || fieldName === 'email' || fieldName === 'password' || fieldName === 'confirm_password') {
                validateField(field, fieldName);
            }
            
            // Validation spéciale pour la confirmation du mot de passe
            if (fieldName === 'confirm_password') {
                const password = document.getElementById('password').value;
                if (field.value !== password) {
                    showError('confirm_password-error', 'Les mots de passe ne correspondent pas');
                } else {
                    hideError('confirm_password-error');
                }
            }
        });
    </script>
</body>
</html>