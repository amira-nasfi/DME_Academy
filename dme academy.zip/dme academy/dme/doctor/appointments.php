<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

require_login();
check_user_type('doctor');

// Actions sur rendez-vous
if (isset($_GET['action']) && isset($_GET['id'])) {
    $appointment_id = $_GET['id'];
    switch ($_GET['action']) {
        case 'confirm':
            updateAppointmentStatus($appointment_id, 'scheduled');
            break;
        case 'complete':
            updateAppointmentStatus($appointment_id, 'completed');
            break;
        case 'cancel':
            updateAppointmentStatus($appointment_id, 'cancelled');
            break;
    }
    header('Location: appointments.php');
    exit();
}

$doctor_id = $_SESSION['user_id'];
// Either use getDoctorAppointments() (now modified) or getDoctorAppointmentsWithDetails()
$appointments = getDoctorAppointments($doctor_id); 
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rendez-vous - Médecin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <h1>Gestion des Rendez-vous</h1>

        <div class="appointments-list">
            <h2>Liste des rendez-vous</h2>
            <table>
                <thead>
                    <tr>
                        <th>Date et Heure</th>
                        <th>Patient</th>
                        <th>Motif</th>
                        <th>Statut</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($appointments as $appointment): ?>
                    <tr>
                        <td><?= formatDateTime($appointment['date'], $appointment['time']) ?></td>
                        <td><?= htmlspecialchars($appointment['patient_name'] ?? 'Patient inconnu') ?></td>
                        <td><?= htmlspecialchars($appointment['reason']) ?></td>
                        <td class="status-<?= $appointment['status'] ?>">
                            <?= ucfirst($appointment['status']) ?>
                        </td>
                        <td>
                            <?php if ($appointment['status'] == 'scheduled'): ?>
                                <a href="?action=complete&id=<?= $appointment['id'] ?>" class="btn complete">Terminer</a>
                                <a href="?action=cancel&id=<?= $appointment['id'] ?>" class="btn cancel">Annuler</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <a href="create_appointment.php" class="btn">Créer un nouveau rendez-vous</a>
    </div>

    <script src="../assets/js/script.js"></script>
</body>
</html>