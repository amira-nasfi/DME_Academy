<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

check_user_type(['doctor', 'admin']);

// Vérification du paramètre patient_id
if (empty($_GET['patient_id']) || !ctype_digit($_GET['patient_id'])) {
    $_SESSION['error'] = "Identifiant patient invalide";
    header('Location: patients.php');
    exit();
}

$patient_id = (int)$_GET['patient_id'];

// Vérification que le médecin a accès à ce patient
$access_stmt = $pdo->prepare("SELECT COUNT(*) FROM medical_records 
                            WHERE patient_id = ? AND doctor_id = ?");
$access_stmt->execute([$patient_id, $_SESSION['user_id']]);
$has_access = $access_stmt->fetchColumn();

if (!$has_access && $_SESSION['user_type'] !== 'admin') {
    $_SESSION['error'] = "Accès non autorisé à ce dossier patient";
    header('Location: patients.php');
    exit();
}

// Récupération des infos du patient
$patient_stmt = $pdo->prepare("SELECT u.*, p.insurance_number, p.blood_type, p.allergies 
                             FROM users u 
                             JOIN patients p ON u.id = p.user_id 
                             WHERE u.id = ? AND u.user_type = 'patient'");
$patient_stmt->execute([$patient_id]);
$patient = $patient_stmt->fetch(PDO::FETCH_ASSOC);

if (!$patient) {
    $_SESSION['error'] = "Patient non trouvé";
    header('Location: patients.php');
    exit();
}

// Récupérer les signes vitaux
$vitals_stmt = $pdo->prepare("SELECT * FROM vital_signs 
                             WHERE patient_id = ? 
                             ORDER BY date_recorded DESC 
                             LIMIT 1");
$vitals_stmt->execute([$patient_id]);
$latest_vitals = $vitals_stmt->fetch(PDO::FETCH_ASSOC);

// Récupérer les dossiers médicaux
$records_stmt = $pdo->prepare("SELECT mr.*, CONCAT(u.first_name, ' ', u.last_name) AS doctor_name 
                              FROM medical_records mr
                              JOIN users u ON mr.doctor_id = u.id
                              WHERE mr.patient_id = ? 
                              ORDER BY mr.created_at DESC
                              LIMIT 5");
$records_stmt->execute([$patient_id]);
$records = $records_stmt->fetchAll(PDO::FETCH_ASSOC);

// Récupérer les prescriptions
$prescriptions_stmt = $pdo->prepare("SELECT p.*, CONCAT(u.first_name, ' ', u.last_name) AS doctor_name 
                                    FROM prescriptions p
                                    JOIN users u ON p.doctor_id = u.id
                                    WHERE p.patient_id = ?
                                    ORDER BY p.prescription_date DESC
                                    LIMIT 5");
$prescriptions_stmt->execute([$patient_id]);
$prescriptions = $prescriptions_stmt->fetchAll(PDO::FETCH_ASSOC);

require_once __DIR__ . '/../includes/header_footer.php';
?>

<div class="doctor-container">
    <h1>DPI - Dossier Patient Informatisé</h1>
    <h2><?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?></h2>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert error"><?= $_SESSION['error'] ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php elseif (isset($_SESSION['success'])): ?>
        <div class="alert success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <!-- Section Informations de base -->
    <div class="patient-info-section">
        <div class="info-card">
            <h3>Informations Personnelles</h3>
            <p><strong>Date de naissance:</strong> <?= date('d/m/Y', strtotime($patient['date_of_birth'])) ?></p>
            <p><strong>Âge:</strong> <?= calculateAge($patient['date_of_birth']) ?> ans</p>
            <p><strong>Email:</strong> <?= htmlspecialchars($patient['email']) ?></p>
            <p><strong>Téléphone:</strong> <?= htmlspecialchars($patient['phone'] ?? 'Non renseigné') ?></p>
        </div>
        
        <div class="info-card">
            <h3>Informations Médicales</h3>
            <p><strong>Groupe sanguin:</strong> <?= htmlspecialchars($patient['blood_type'] ?? 'Non renseigné') ?></p>
            <p><strong>Allergies:</strong> <?= htmlspecialchars($patient['allergies'] ?? 'Aucune connue') ?></p>
            <p><strong>N° assurance:</strong> <?= htmlspecialchars($patient['insurance_number']) ?></p>
        </div>
        
        <?php if ($latest_vitals): ?>
        <div class="info-card">
            <h3>Signes Vitaux</h3>
            <p><strong>Température:</strong> <?= htmlspecialchars($latest_vitals['temperature']) ?> °C</p>
            <p><strong>Tension artérielle:</strong> <?= htmlspecialchars($latest_vitals['blood_pressure']) ?></p>
            <p><strong>Rythme cardiaque:</strong> <?= htmlspecialchars($latest_vitals['heart_rate']) ?> bpm</p>
            <p><strong>Fréquence respiratoire:</strong> <?= htmlspecialchars($latest_vitals['respiratory_rate']) ?> rpm</p>
            <p><small>Mesuré le <?= date('d/m/Y H:i', strtotime($latest_vitals['date_recorded'])) ?></small></p>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- Onglets -->
    <div class="tabs">
        <button class="tab-btn active" onclick="openTab(event, 'medical-records')">Dossiers Médicaux</button>
        <button class="tab-btn" onclick="openTab(event, 'prescriptions')">Prescriptions</button>
        <button class="tab-btn" onclick="openTab(event, 'add-record')">Nouveau Dossier</button>
    </div>
    
    <!-- Contenu des onglets -->
    <div id="medical-records" class="tab-content" style="display:block;">
        <div class="tab-header">
            <h3>Historique Médical Récent</h3>
            <a href="medical_records.php?patient_id=<?= $patient_id ?>" class="btn-action">Voir tout l'historique</a>
        </div>
        
        <?php if (empty($records)): ?>
            <p>Aucun dossier médical trouvé.</p>
        <?php else: ?>
            <div class="records-list">
                <?php foreach ($records as $record): ?>
                <div class="record-item">
                    <div class="record-header">
                        <h4><?= date('d/m/Y H:i', strtotime($record['created_at'])) ?> - <?= htmlspecialchars(ucfirst($record['record_type'])) ?></h4>
                        <span class="doctor-name">Dr. <?= htmlspecialchars($record['doctor_name']) ?></span>
                    </div>
                    <p><strong>Diagnostic:</strong> <?= nl2br(htmlspecialchars($record['diagnosis'])) ?></p>
                    <p><strong>Traitement:</strong> <?= nl2br(htmlspecialchars($record['treatment'])) ?></p>
                    <!-- In the records list -->
<div class="record-actions">
    <a href="edit_record.php?patient_id=<?= $patient_id ?>&record_id=<?= $record['id'] ?>" class="btn-action">Modifier</a>
</div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <div id="prescriptions" class="tab-content">
        <div class="tab-header">
            <h3>Prescriptions Récentes</h3>
            <a href="prescriptions.php?patient_id=<?= $patient_id ?>" class="btn-action">Voir toutes les prescriptions</a>
        </div>
        
        <?php if (empty($prescriptions)): ?>
            <p>Aucune prescription trouvée.</p>
        <?php else: ?>
            <div class="prescriptions-list">
                <?php foreach ($prescriptions as $prescription): ?>
                <div class="prescription-item">
                    <div class="prescription-header">
                        <h4><?= date('d/m/Y', strtotime($prescription['prescription_date'])) ?></h4>
                        <span class="doctor-name">Dr. <?= htmlspecialchars($prescription['doctor_name']) ?></span>
                    </div>
                    <p><strong>Médicaments:</strong> <?= nl2br(htmlspecialchars($prescription['medication'])) ?></p>
                    <p><strong>Posologie:</strong> <?= nl2br(htmlspecialchars($prescription['dosage'])) ?></p>
                    <p><strong>Instructions:</strong> <?= nl2br(htmlspecialchars($prescription['instructions'])) ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <div id="add-record" class="tab-content">
    <h3>Créer un Nouveau Dossier Médical</h3>
    <a href="edit_record.php?patient_id=<?= $patient_id ?>&action=new" class="btn-submit">Créer un nouveau dossier</a>
</div>
        <form method="POST" action="save_record.php">
            <input type="hidden" name="patient_id" value="<?= $patient_id ?>">
            
            <div class="form-group">
                <label>Type de dossier</label>
                <select name="record_type" required>
                    <option value="">Sélectionner un type</option>
                    <option value="consultation">Consultation</option>
                    <option value="hospitalization">Hospitalisation</option>
                    <option value="surgery">Chirurgie</option>
                    <option value="test">Test</option>
                    <option value="prescription">Prescription</option>
                    <option value="other">Autre</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>Date</label>
                <input type="datetime-local" name="record_date" value="<?= date('Y-m-d\TH:i') ?>" required>
            </div>
            
            <div class="form-group">
                <label>Diagnostic</label>
                <textarea name="diagnosis" rows="5" required placeholder="Décrivez le diagnostic..."></textarea>
            </div>
            
            <div class="form-group">
                <label>Traitement</label>
                <textarea name="treatment" rows="5" placeholder="Décrivez le traitement prescrit..."></textarea>
            </div>
            
            <div class="form-group">
                <label>Notes complémentaires</label>
                <textarea name="description" rows="5" placeholder="Ajoutez des notes supplémentaires..."></textarea>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn-submit">Enregistrer</button>
                <button type="reset" class="btn-cancel">Effacer</button>
            </div>
        </form>
    </div>
</div>

<script>
function openTab(evt, tabName) {
    const tabContents = document.getElementsByClassName("tab-content");
    for (let i = 0; i < tabContents.length; i++) {
        tabContents[i].style.display = "none";
    }
    
    const tabButtons = document.getElementsByClassName("tab-btn");
    for (let i = 0; i < tabButtons.length; i++) {
        tabButtons[i].className = tabButtons[i].className.replace(" active", "");
    }
    
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}
</script>

<?php show_footer(); ?>