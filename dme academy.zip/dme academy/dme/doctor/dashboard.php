<?php
session_start();
require_once '../includes/config.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

require_login();
check_user_type('doctor');

// Récupérer les informations du médecin
$doctor_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT u.*, d.* FROM users u JOIN doctors d ON u.id = d.user_id WHERE u.id = ?");
$stmt->execute([$doctor_id]);
$doctor = $stmt->fetch(PDO::FETCH_ASSOC);

// Récupérer les statistiques
$stmt = $pdo->prepare("SELECT COUNT(DISTINCT patient_id) as total_patients FROM medical_records WHERE doctor_id = ?");
$stmt->execute([$doctor_id]);
$stats = $stmt->fetch(PDO::FETCH_ASSOC);

// Récupérer tous les patients
$stmt = $pdo->prepare("SELECT id, first_name, last_name, email, phone FROM users WHERE user_type = 'patient' ORDER BY last_name ASC");
$stmt->execute();
$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord Médecin - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/patients-enhancements.css">
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <div class="header-left">
                <img src="../assets/images/logo.png" alt="Logo DME" class="logo-small">
                <h1>Tableau de bord Médecin</h1>
            </div>
            <div class="header-right">
                <span class="welcome-message">Bonjour, Dr. <?= htmlspecialchars($_SESSION['username'] ?? '') ?></span>
                <a href="../logout.php" class="btn btn-logout">Déconnexion</a>
            </div>
        </header>

        <div class="dashboard-content">
            <aside class="sidebar">
                <nav>
                    <ul>
                        <li class="active"><a href="dashboard.php">Accueil</a></li>
                        <li><a href="appointments.php">Rendez-vous</a></li>
                        <li><a href="profile.php">Profil</a></li>
                        <li><a href="patients.php">Patients</a></li>
                        <li><a href="prescriptions.php">Ordonnances</a></li>
                        <li><a href="medical_records.php">Dossiers médicaux</a></li>
                        </ul>
                </nav>
            </aside>

            <main class="main-content">
                <div class="card summary-card">
                    <h2>Statistiques</h2>
                    <div class="summary-grid">
                        <div class="summary-item">
                            <h3>Patients suivis</h3>
                            <p><?= $stats['total_patients'] ?></p>
                        </div>
                        <div class="summary-item">
                            <h3>Spécialisation</h3>
                            <p><?= $doctor['specialization'] ?? 'Non spécifiée' ?></p>
                        </div>
                        <div class="summary-item">
                            <h3>Numéro de licence</h3>
                            <p><?= $doctor['license_number'] ?></p>
                        </div>
                    </div>
                </div>

                <div class="card patient-list">
                    <h2>Liste des patients</h2>
                    <?php if (empty($patients)): ?>
                        <p>Aucun patient trouvé.</p>
                    <?php else: ?>
                        <table class="records-table">
                            <thead>
                                <tr>
                                    <th>Nom</th>
                                    <th>Email</th>
                                    <th>Téléphone</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($patients as $patient): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?></td>
                                        <td><?= htmlspecialchars($patient['email']) ?></td>
                                        <td><?= htmlspecialchars($patient['phone']) ?></td>
                                        <td>
                                            <a href="patient_dossier.php?patient_id=<?= $patient['id'] ?>" class="btn btn-view">Voir</a>
                                            <a href="create_appointment.php?patient_id=<?= $patient['id'] ?>" class="btn btn-primary">Rendez-vous</a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>

    <script src="../assets/js/script.js"></script>
    
</body>
</html>