<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

check_user_type('doctor');

$title = "Dossiers Médicaux";
$patient_id = isset($_GET['patient_id']) ? (int)$_GET['patient_id'] : null;

// Vérifier l'accès du médecin à ce patient si patient_id est spécifié
if ($patient_id) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM medical_records 
                          WHERE patient_id = ? AND doctor_id = ?");
    $stmt->execute([$patient_id, $_SESSION['user_id']]);
    $has_access = $stmt->fetchColumn();
    
    if (!$has_access) {
        $_SESSION['error'] = "Accès non autorisé à ce dossier patient";
        header("Location: /dme/doctor/patients.php");
        exit;
    }
}

// Récupérer les informations du patient si patient_id est spécifié
$patient_info = null;
if ($patient_id) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$patient_id]);
    $patient_info = $stmt->fetch(PDO::FETCH_ASSOC);
}

// Récupérer les dossiers médicaux
$sql = "SELECT mr.*, u.first_name, u.last_name 
       FROM medical_records mr
       JOIN users u ON mr.patient_id = u.id
       WHERE mr.doctor_id = ?";
$params = [$_SESSION['user_id']];

if ($patient_id) {
    $sql .= " AND mr.patient_id = ?";
    $params[] = $patient_id;
}

$sql .= " ORDER BY mr.created_at DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$records = $stmt->fetchAll(PDO::FETCH_ASSOC);

require_once __DIR__ . '/../includes/header_footer.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $title ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
  <div class="header">
    <div class="container header-content">
      <h1><?= $patient_id ? 'Dossier Médical' : 'Mes Dossiers Médicaux' ?></h1>
      <div class="actions">
        <a href="add_record.php<?= $patient_id ? '?patient_id='.$patient_id : '' ?>" class="btn btn-primary">Nouvelle Entrée</a>
      </div>
    </div>
  </div>

  <div class="container">
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert alert-danger"><?= $_SESSION['error'] ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php elseif (isset($_SESSION['success'])): ?>
        <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>

    <?php if ($patient_info): ?>
    <div class="patient-info">
      <div class="patient-info-item">
        <div class="patient-info-label">Nom du Patient</div>
        <div class="patient-info-value"><?= htmlspecialchars($patient_info['first_name'].' '.$patient_info['last_name']) ?></div>
      </div>
      <div class="patient-info-item">
        <div class="patient-info-label">Date de Naissance</div>
        <div class="patient-info-value">
          <?= $patient_info['birth_date'] ? formatDate($patient_info['birth_date']) : 'Non renseignée' ?>
          <?php if ($patient_info['birth_date']): ?>
            (<?= calculateAge($patient_info['birth_date']) ?> ans)
          <?php endif; ?>
        </div>
      </div>
      <div class="patient-info-item">
        <div class="patient-info-label">Numéro de Dossier</div>
        <div class="patient-info-value">MED-<?= str_pad($patient_info['id'], 4, '0', STR_PAD_LEFT) ?></div>
      </div>
      <div class="patient-info-item">
        <div class="patient-info-label">Groupe Sanguin</div>
        <div class="patient-info-value"><?= $patient_info['blood_group'] ? htmlspecialchars($patient_info['blood_group']) : 'Non renseigné' ?></div>
      </div>
    </div>
    <?php endif; ?>

    <?php if ($patient_id): ?>
    <div class="vital-signs">
      <div class="vital-sign">
        <div class="vital-sign-value">72</div>
        <div class="vital-sign-label">BPM</div>
      </div>
      <div class="vital-sign">
        <div class="vital-sign-value">120/80</div>
        <div class="vital-sign-label">mmHg</div>
      </div>
      <div class="vital-sign">
        <div class="vital-sign-value">36.6</div>
        <div class="vital-sign-label">°C</div>
      </div>
      <div class="vital-sign">
        <div class="vital-sign-value">98</div>
        <div class="vital-sign-label">SpO2%</div>
      </div>
    </div>
    <?php endif; ?>

    <div class="card">
      <div class="card-header">
        <h2 class="card-title">Historique Médical</h2>
        <a href="add_record.php<?= $patient_id ? '?patient_id='.$patient_id : '' ?>" class="btn btn-primary btn-sm">Ajouter une entrée</a>
      </div>
      <div class="table-responsive">
        <?php if (empty($records)): ?>
          <div class="p-4 text-center">Aucun dossier médical trouvé.</div>
        <?php else: ?>
          <table class="table">
            <thead>
              <tr>
                <th>Date</th>
                <?php if (!$patient_id): ?>
                  <th>Patient</th>
                <?php endif; ?>
                <th>Type</th>
                <th>Diagnostic</th>
                <th>Traitement</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($records as $record): ?>
                <tr>
                  <td><?= formatDate($record['record_date']) ?></td>
                  <?php if (!$patient_id): ?>
                    <td><?= htmlspecialchars($record['first_name'].' '.$record['last_name']) ?></td>
                  <?php endif; ?>
                  <td><?= htmlspecialchars($record['record_type']) ?></td>
                  <td><?= htmlspecialchars(truncateText($record['diagnosis_description'], 50)) ?></td>
                  <td><?= htmlspecialchars(truncateText($record['treatment'], 50)) ?></td>
                  <td>
                    <a href="view_record.php?id=<?= $record['id'] ?>" class="btn btn-sm btn-primary">Voir</a>
                    <a href="delete_record.php?id=<?= $record['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Êtes-vous sûr de vouloir supprimer ce dossier ?')">Supprimer</a>
                    <a href="patient_dossier.php?patient_id=<?= $patient['id'] ?>" class="btn btn-view">Voir</a>
                    <a href="create_appointment.php?patient_id=<?= $patient['id'] ?>" class="btn btn-primary">Rendez-vous</a>
                  </td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <script src="../assets/js/script.js"></script>
</body>
</html>
<?php
echo show_footer();
?>