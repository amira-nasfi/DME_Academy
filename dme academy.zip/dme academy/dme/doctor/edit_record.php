<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

check_user_type(['doctor', 'admin']);

// Vérification du paramètre patient_id
if (empty($_GET['patient_id']) || !ctype_digit($_GET['patient_id'])) {
    $_SESSION['error'] = "Identifiant patient invalide";
    header('Location: patients.php');
    exit();
}

$patient_id = (int)$_GET['patient_id'];

// Vérification que le médecin a accès à ce patient
$access_stmt = $pdo->prepare("SELECT COUNT(*) FROM medical_records 
                            WHERE patient_id = ? AND doctor_id = ?");
$access_stmt->execute([$patient_id, $_SESSION['user_id']]);
$has_access = $access_stmt->fetchColumn();

if (!$has_access && $_SESSION['user_type'] !== 'admin') {
    $_SESSION['error'] = "Accès non autorisé à ce dossier patient";
    header('Location: patients.php');
    exit();
}

// Récupération des infos du patient
$patient_stmt = $pdo->prepare("SELECT u.*, p.insurance_number, p.blood_type, p.allergies 
                             FROM users u 
                             JOIN patients p ON u.id = p.user_id 
                             WHERE u.id = ? AND u.user_type = 'patient'");
$patient_stmt->execute([$patient_id]);
$patient = $patient_stmt->fetch(PDO::FETCH_ASSOC);

if (!$patient) {
    $_SESSION['error'] = "Patient non trouvé";
    header('Location: patients.php');
    exit();
}

// Récupérer les signes vitaux
$vitals_stmt = $pdo->prepare("SELECT * FROM vital_signs 
                             WHERE patient_id = ? 
                             ORDER BY date_recorded DESC 
                             LIMIT 1");
$vitals_stmt->execute([$patient_id]);
$latest_vitals = $vitals_stmt->fetch(PDO::FETCH_ASSOC);

// Récupérer les dossiers médicaux (augmenté à 15 enregistrements)
$records_stmt = $pdo->prepare("SELECT mr.*, CONCAT(u.first_name, ' ', u.last_name) AS doctor_name 
                              FROM medical_records mr
                              JOIN users u ON mr.doctor_id = u.id
                              WHERE mr.patient_id = ? 
                              ORDER BY mr.created_at DESC
                              LIMIT 15");
$records_stmt->execute([$patient_id]);
$records = $records_stmt->fetchAll(PDO::FETCH_ASSOC);

// Récupérer les prescriptions
$prescriptions_stmt = $pdo->prepare("SELECT p.*, CONCAT(u.first_name, ' ', u.last_name) AS doctor_name 
                                    FROM prescriptions p
                                    JOIN users u ON p.doctor_id = u.id
                                    WHERE p.patient_id = ?
                                    ORDER BY p.prescription_date DESC
                                    LIMIT 5");
$prescriptions_stmt->execute([$patient_id]);
$prescriptions = $prescriptions_stmt->fetchAll(PDO::FETCH_ASSOC);

require_once __DIR__ . '/../includes/header_footer.php';
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DPI - <?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?> | <?= APP_NAME ?></title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Enhanced Styles */
        .record-item {
            border-left: 4px solid #4a89dc;
            transition: all 0.3s ease;
            margin-bottom: 15px;
            padding: 15px;
            background: white;
            border-radius: 4px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        .record-item:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        .record-type-badge {
            padding: 3px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
            color: white;
            display: inline-block;
            margin-right: 10px;
        }
        .consultation { background: #4a89dc; }
        .prescription { background: #37bc9b; }
        .hospitalization { background: #da4453; }
        .surgery { background: #8cc152; }
        .test { background: #f6bb42; }
        .other { background: #967adc; }
        .record-actions {
            margin-top: 15px;
            display: flex;
            gap: 10px;
        }
        .btn-action {
            padding: 8px 15px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.2s;
        }
        .btn-edit {
            background: #4a89dc;
            color: white;
        }
        .btn-edit:hover {
            background: #3a6fc8;
        }
        .btn-quick-view {
            background: #a0d468;
            color: white;
        }
        .btn-quick-view:hover {
            background: #8bc253;
        }
        .empty-state {
            text-align: center;
            padding: 40px;
            color: #666;
        }
        .empty-state i {
            font-size: 50px;
            color: #ddd;
            margin-bottom: 15px;
        }
        .tab-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .creation-options {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        .creation-card {
            cursor: pointer;
            padding: 20px;
            border-radius: 8px;
            text-align: center;
            transition: all 0.3s ease;
            background: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        .creation-card:hover {
            background: #f5f7fa;
            transform: translateY(-3px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        .creation-card i {
            font-size: 30px;
            margin-bottom: 10px;
            color: #4a89dc;
        }
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 5px;
            width: 80%;
            max-width: 800px;
            max-height: 80vh;
            overflow-y: auto;
            position: relative;
        }
        .close {
            position: absolute;
            right: 15px;
            top: 10px;
            font-size: 24px;
            cursor: pointer;
        }
    </style>
</head>
<body>
<div class="doctor-container">
    <h1>DPI - Dossier Patient Informatisé</h1>
    <h2><?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?></h2>
    
    <?php if (isset($_SESSION['error'])): ?>
        <div class="alert error"><?= $_SESSION['error'] ?></div>
        <?php unset($_SESSION['error']); ?>
    <?php elseif (isset($_SESSION['success'])): ?>
        <div class="alert success"><?= $_SESSION['success'] ?></div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    
    <!-- Section Informations de base -->
    <div class="patient-info-section">
        <div class="info-card">
            <h3><i class="fas fa-user"></i> Informations Personnelles</h3>
            <p><strong>Date de naissance:</strong> <?= date('d/m/Y', strtotime($patient['date_of_birth'])) ?></p>
            <p><strong>Âge:</strong> <?= calculateAge($patient['date_of_birth']) ?> ans</p>
            <p><strong>Email:</strong> <?= htmlspecialchars($patient['email']) ?></p>
            <p><strong>Téléphone:</strong> <?= htmlspecialchars($patient['phone'] ?? 'Non renseigné') ?></p>
        </div>
        
        <div class="info-card">
            <h3><i class="fas fa-heartbeat"></i> Informations Médicales</h3>
            <p><strong>Groupe sanguin:</strong> <?= htmlspecialchars($patient['blood_type'] ?? 'Non renseigné') ?></p>
            <p><strong>Allergies:</strong> <?= htmlspecialchars($patient['allergies'] ?? 'Aucune connue') ?></p>
            <p><strong>N° assurance:</strong> <?= htmlspecialchars($patient['insurance_number']) ?></p>
        </div>
        
        <?php if ($latest_vitals): ?>
        <div class="info-card">
            <h3><i class="fas fa-heart"></i> Signes Vitaux</h3>
            <p><strong>Température:</strong> <?= htmlspecialchars($latest_vitals['temperature']) ?> °C</p>
            <p><strong>Tension artérielle:</strong> <?= htmlspecialchars($latest_vitals['blood_pressure']) ?></p>
            <p><strong>Rythme cardiaque:</strong> <?= htmlspecialchars($latest_vitals['heart_rate']) ?> bpm</p>
            <p><strong>Fréquence respiratoire:</strong> <?= htmlspecialchars($latest_vitals['respiratory_rate']) ?> rpm</p>
            <p><small>Mesuré le <?= date('d/m/Y H:i', strtotime($latest_vitals['date_recorded'])) ?></small></p>
        </div>
        <?php endif; ?>
    </div>
    
    <!-- Onglets -->
    <div class="tabs">
        <button class="tab-btn active" onclick="openTab(event, 'medical-records')">
            <i class="fas fa-file-medical"></i> Dossiers Médicaux
        </button>
        <button class="tab-btn" onclick="openTab(event, 'prescriptions')">
            <i class="fas fa-prescription-bottle-alt"></i> Prescriptions
        </button>
        <button class="tab-btn" onclick="openTab(event, 'add-record')">
            <i class="fas fa-plus-circle"></i> Nouveau Dossier
        </button>
    </div>
    
    <!-- Contenu des onglets -->
    <div id="medical-records" class="tab-content" style="display:block;">
        <div class="tab-header">
            <h3><i class="fas fa-history"></i> Historique Médical</h3>
            <div class="action-buttons">
                <a href="medical_records.php?patient_id=<?= $patient_id ?>" class="btn-action">
                    <i class="fas fa-list"></i> Voir tout
                </a>
                <button class="btn-action" onclick="window.print()">
                    <i class="fas fa-print"></i> Imprimer
                </button>
            </div>
        </div>
        
        <?php if (empty($records)): ?>
            <div class="empty-state">
                <i class="fas fa-folder-open"></i>
                <p>Aucun dossier médical trouvé</p>
                <a href="#add-record" class="btn-submit" onclick="switchToAddTab()">
                    <i class="fas fa-plus"></i> Créer un premier dossier
                </a>
            </div>
        <?php else: ?>
            <div class="records-list">
                <?php foreach ($records as $record): ?>
                <div class="record-item">
                    <div class="record-header">
                        <span class="record-type-badge <?= $record['record_type'] ?>">
                            <?= ucfirst($record['record_type']) ?>
                        </span>
                        <h4><?= date('d/m/Y H:i', strtotime($record['created_at'])) ?></h4>
                        <span class="doctor-name">Dr. <?= htmlspecialchars($record['doctor_name']) ?></span>
                    </div>
                    
                    <div class="record-summary">
                        <div class="diagnosis-summary">
                            <strong>Diagnostic:</strong>
                            <?= nl2br(htmlspecialchars(substr($record['diagnosis'], 0, 100) . (strlen($record['diagnosis']) > 100 ? '...' : ''))) ?>
                        </div>
                        
                        <div class="treatment-summary">
                            <strong>Traitement:</strong>
                            <?= nl2br(htmlspecialchars(substr($record['treatment'], 0, 100) . (strlen($record['treatment']) > 100 ? '...' : ''))) ?>
                        </div>
                    </div>
                    
                    <div class="record-actions">
                        <a href="edit_record.php?patient_id=<?= $patient_id ?>&record_id=<?= $record['id'] ?>" 
                           class="btn-action btn-edit">
                            <i class="fas fa-edit"></i> Modifier
                        </a>
                        <button class="btn-action btn-quick-view" 
                                onclick="showQuickView(<?= $record['id'] ?>)">
                            <i class="fas fa-eye"></i> Aperçu rapide
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <div id="prescriptions" class="tab-content">
        <div class="tab-header">
            <h3><i class="fas fa-prescription-bottle-alt"></i> Prescriptions Récentes</h3>
            <a href="prescriptions.php?patient_id=<?= $patient_id ?>" class="btn-action">
                <i class="fas fa-list"></i> Voir toutes
            </a>
        </div>
        
        <?php if (empty($prescriptions)): ?>
            <div class="empty-state">
                <i class="fas fa-prescription-bottle"></i>
                <p>Aucune prescription trouvée</p>
            </div>
        <?php else: ?>
            <div class="prescriptions-list">
                <?php foreach ($prescriptions as $prescription): ?>
                <div class="record-item">
                    <div class="record-header">
                        <span class="record-type-badge prescription">
                            Prescription
                        </span>
                        <h4><?= date('d/m/Y', strtotime($prescription['prescription_date'])) ?></h4>
                        <span class="doctor-name">Dr. <?= htmlspecialchars($prescription['doctor_name']) ?></span>
                    </div>
                    <div class="record-summary">
                        <p><strong>Médicaments:</strong> <?= nl2br(htmlspecialchars(substr($prescription['medication'], 0, 100) . (strlen($prescription['medication']) > 100 ? '...' : ''))) ?></p>
                        <p><strong>Posologie:</strong> <?= nl2br(htmlspecialchars(substr($prescription['dosage'], 0, 100) . (strlen($prescription['dosage']) > 100 ? '...' : ''))) ?></p>
                    </div>
                    <div class="record-actions">
                        <a href="prescriptions.php?action=view&id=<?= $prescription['id'] ?>" class="btn-action btn-edit">
                            <i class="fas fa-eye"></i> Voir détails
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <div id="add-record" class="tab-content">
        <h3><i class="fas fa-plus-circle"></i> Créer un Nouveau Dossier</h3>
        
        <div class="creation-options">
            <div class="creation-card" onclick="location.href='edit_record.php?patient_id=<?= $patient_id ?>&record_type=consultation'">
                <i class="fas fa-stethoscope"></i>
                <h4>Consultation</h4>
            </div>
            
            <div class="creation-card" onclick="location.href='edit_record.php?patient_id=<?= $patient_id ?>&record_type=prescription'">
                <i class="fas fa-pills"></i>
                <h4>Prescription</h4>
            </div>
            
            <div class="creation-card" onclick="location.href='edit_record.php?patient_id=<?= $patient_id ?>&record_type=hospitalization'">
                <i class="fas fa-procedures"></i>
                <h4>Hospitalisation</h4>
            </div>
            
            <div class="creation-card" onclick="location.href='edit_record.php?patient_id=<?= $patient_id ?>&record_type=test'">
                <i class="fas fa-vial"></i>
                <h4>Test</h4>
            </div>
        </div>
        
        <div class="quick-create-form">
            <h4><i class="fas fa-bolt"></i> Création rapide</h4>
            <form method="POST" action="save_record.php">
                <input type="hidden" name="patient_id" value="<?= $patient_id ?>">
                
                <div class="form-group">
                    <label>Type</label>
                    <select name="record_type" class="quick-select" required>
                        <option value="">Sélectionner...</option>
                        <option value="consultation">Consultation</option>
                        <option value="prescription">Prescription</option>
                        <option value="hospitalization">Hospitalisation</option>
                        <option value="test">Test</option>
                        <option value="other">Autre</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label>Diagnostic principal</label>
                    <textarea name="diagnosis" rows="2" required placeholder="Décrivez le diagnostic..."></textarea>
                </div>
                
                <div class="form-group">
                    <label>Traitement</label>
                    <textarea name="treatment" rows="2" placeholder="Décrivez le traitement..."></textarea>
                </div>
                
                <div class="form-actions">
                    <button type="submit" name="save_record" class="btn-submit">
                        <i class="fas fa-save"></i> Enregistrer
                    </button>
                    <button type="reset" class="btn-cancel">
                        <i class="fas fa-eraser"></i> Effacer
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Quick View Modal -->
<div id="quickViewModal" class="modal">
    <div class="modal-content">
        <span class="close" onclick="closeModal()">&times;</span>
        <div id="quickViewContent"></div>
    </div>
</div>

<script>
// Tab functionality
function openTab(evt, tabName) {
    const tabContents = document.getElementsByClassName("tab-content");
    for (let i = 0; i < tabContents.length; i++) {
        tabContents[i].style.display = "none";
    }
    
    const tabButtons = document.getElementsByClassName("tab-btn");
    for (let i = 0; i < tabButtons.length; i++) {
        tabButtons[i].className = tabButtons[i].className.replace(" active", "");
    }
    
    document.getElementById(tabName).style.display = "block";
    evt.currentTarget.className += " active";
}

// Quick View functions
function showQuickView(recordId) {
    fetch(`../api/get_record.php?id=${recordId}`)
        .then(response => response.text())
        .then(data => {
            document.getElementById('quickViewContent').innerHTML = data;
            document.getElementById('quickViewModal').style.display = 'block';
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Erreur lors du chargement du dossier');
        });
}

function closeModal() {
    document.getElementById('quickViewModal').style.display = 'none';
}

function switchToAddTab() {
    document.querySelector('button[onclick*="add-record"]').click();
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('quickViewModal');
    if (event.target == modal) {
        closeModal();
    }
}
</script>

<?php show_footer(); ?>