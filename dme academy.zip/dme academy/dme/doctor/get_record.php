<?php
require_once __DIR__ . '/../../includes/config.php';
require_once __DIR__ . '/../../includes/auth.php';

check_user_type(['doctor', 'admin']);

if (empty($_GET['id']) || !is_numeric($_GET['id'])) {
    die("ID de dossier invalide");
}

$record_id = (int)$_GET['id'];

// Verify access
$stmt = $pdo->prepare("SELECT mr.*, u.first_name, u.last_name 
                      FROM medical_records mr
                      JOIN users u ON mr.doctor_id = u.id
                      WHERE mr.id = ? AND (mr.doctor_id = ? OR ? = 'admin')");
$stmt->execute([$record_id, $_SESSION['user_id'], $_SESSION['user_type']]);
$record = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$record) {
    die("Dossier non trouvé ou accès non autorisé");
}

header('Content-Type: text/html');
?>
<div class="record-full-view">
    <h3>Dossier #<?= $record['id'] ?></h3>
    <p><strong>Type:</strong> <?= ucfirst($record['record_type']) ?></p>
    <p><strong>Date:</strong> <?= date('d/m/Y H:i', strtotime($record['created_at'])) ?></p>
    <p><strong>Médecin:</strong> Dr. <?= htmlspecialchars($record['first_name'] . ' ' . $record['last_name']) ?></p>
    
    <div class="section">
        <h4>Diagnostic</h4>
        <div class="content"><?= nl2br(htmlspecialchars($record['diagnosis'])) ?></div>
    </div>
    
    <div class="section">
        <h4>Traitement</h4>
        <div class="content"><?= nl2br(htmlspecialchars($record['treatment'])) ?></div>
    </div>
    
    <?php if (!empty($record['description'])): ?>
    <div class="section">
        <h4>Notes complémentaires</h4>
        <div class="content"><?= nl2br(htmlspecialchars($record['description'])) ?></div>
    </div>
    <?php endif; ?>
    
    <div class="actions">
        <a href="edit_record.php?record_id=<?= $record['id'] ?>&patient_id=<?= $record['patient_id'] ?>" 
           class="btn-action btn-edit">
            <i class="fas fa-edit"></i> Modifier
        </a>
    </div>
</div>