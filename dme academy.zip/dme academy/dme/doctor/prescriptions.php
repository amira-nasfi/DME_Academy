<?php
define('ACCESS_ALLOWED', true);
require_once '../includes/auth.php';
require_once '../includes/db.php';

if ($_SESSION['user_type'] !== 'doctor') {
    header('Location: ../login.php');
    exit();
}

$patients_stmt = $pdo->query("SELECT id, first_name, last_name FROM users WHERE user_type = 'patient'");
$patients = $patients_stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id = $_POST['patient_id'];
    $doctor_id = $_SESSION['user_id'];
    $medication_name = $_POST['medication_name'];
    $dosage = $_POST['dosage'];
    $frequency = $_POST['frequency'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'] ?? null;
    $instructions = $_POST['instructions'];
    $status = $_POST['status'];

    $doctor_stmt = $pdo->prepare("SELECT CONCAT(first_name, ' ', last_name) AS name FROM users WHERE id = ?");
    $doctor_stmt->execute([$doctor_id]);
    $doctor = $doctor_stmt->fetch(PDO::FETCH_ASSOC);
    $doctor_name = $doctor ? $doctor['name'] : 'Inconnu';

    // Étape 1 : créer un dossier médical vide
    $insert_record = $pdo->prepare("INSERT INTO medical_records 
        (patient_id, doctor_id, doctor_name, record_type, record_date) 
        VALUES (?, ?, ?, 'consultation', NOW())");
    $insert_record->execute([$patient_id, $doctor_id, $doctor_name]);
    $record_id = $pdo->lastInsertId();

    // Étape 2 : insérer la prescription AVEC patient_id et doctor_id
    $stmt = $pdo->prepare("INSERT INTO prescriptions 
        (record_id, patient_id, doctor_id, medication_name, dosage, frequency, start_date, end_date, instructions, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$record_id, $patient_id, $doctor_id, $medication_name, $dosage, $frequency, $start_date, $end_date, $instructions, $status]);
    $prescription_id = $pdo->lastInsertId();

    // Étape 3 : mettre à jour le dossier médical avec prescription_id
    $update_record = $pdo->prepare("UPDATE medical_records SET prescription_id = ? WHERE id = ?");
    $update_record->execute([$prescription_id, $record_id]);

    $success = true;
}

function show_header($title = "") {
    return "
    <!DOCTYPE html>
    <html lang='fr'>
    <head>
        <meta charset='UTF-8'>
        <title>$title</title>
        <link rel='stylesheet' href='../assets/css/style.css'>
        <link rel='stylesheet' href='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>
    </head>
    <body>
    ";
}
function show_footer() {
    return "</body></html>";
}

echo show_header("Écrire une ordonnance");
?>

<div class="container mt-5">
    <h2 class="mb-4">Rédiger une prescription</h2>

    <?php if (!empty($success)): ?>
        <div class="alert alert-success">Prescription ajoutée avec succès.</div>
    <?php endif; ?>

    <form method="POST">
        <div class="form-group">
            <label for="patient_id">Choisir un patient</label>
            <select name="patient_id" id="patient_id" class="form-control" required>
                <option value="">-- Sélectionner --</option>
                <?php foreach ($patients as $patient): ?>
                    <option value="<?= $patient['id'] ?>"><?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label>Médicament</label>
            <input type="text" name="medication_name" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Dosage</label>
            <input type="text" name="dosage" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Fréquence</label>
            <input type="text" name="frequency" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Date début</label>
            <input type="date" name="start_date" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Date fin</label>
            <input type="date" name="end_date" class="form-control">
        </div>

        <div class="form-group">
            <label>Instructions</label>
            <textarea name="instructions" class="form-control" rows="3"></textarea>
        </div>

        <div class="form-group">
            <label>Statut</label>
            <select name="status" class="form-control">
                <option value="active">Active</option>
                <option value="completed">Complétée</option>
                <option value="cancelled">Annulée</option>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Envoyer la prescription</button>
    </form>
</div>

<script src="../assets/js/script.js"></script>

<?php echo show_footer(); ?>
