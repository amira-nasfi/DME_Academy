<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

require_login();
check_user_type('doctor');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id = $_POST['patient_id'];
    $doctor_id = $_SESSION['user_id'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $reason = $_POST['reason'];

    if (createAppointment($patient_id, $doctor_id, $date, $time, $reason)) {
        $_SESSION['success'] = "Rendez-vous créé avec succès.";
        header('Location: appointments.php');
        exit();
    } else {
        $error = "Erreur lors de la création du rendez-vous.";
    }
}

$patients = getAllPatients();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Créer un Rendez-vous</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <div class="container">
        <h1>Créer un Rendez-vous</h1>

        <?php if (isset($error)): ?>
            <div class="alert error"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label for="patient_id">Patient</label>
                <select name="patient_id" id="patient_id" required>
                    <option value="">Sélectionner un patient</option>
                    <?php foreach ($patients as $patient): ?>
                    <option value="<?= $patient['id'] ?>">
                        <?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="date">Date</label>
                <input type="date" name="date" id="date" required min="<?= date('Y-m-d') ?>">
            </div>

            <div class="form-group">
                <label for="time">Heure</label>
                <input type="time" name="time" id="time" required>
            </div>

            <div class="form-group">
                <label for="reason">Motif</label>
                <textarea name="reason" id="reason" rows="3" required></textarea>
            </div>

            <button type="submit" class="btn">Créer le rendez-vous</button>
        </form>
    </div>
</body>
</html>
