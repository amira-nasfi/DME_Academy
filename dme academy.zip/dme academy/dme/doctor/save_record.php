<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

check_user_type('doctor');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: patients.php');
    exit();
}

// Validation des données
$required_fields = ['patient_id', 'record_type', 'record_date', 'diagnosis'];
foreach ($required_fields as $field) {
    if (empty($_POST[$field])) {
        $_SESSION['error'] = "Le champ " . str_replace('_', ' ', $field) . " est obligatoire";
        header("Location: " . ($_SERVER['HTTP_REFERER'] ?? 'patients.php'));
        exit();
    }
}

$patient_id = (int)$_POST['patient_id'];
$record_type = sanitize($_POST['record_type']);
$record_date = sanitize($_POST['record_date']);
$diagnosis = sanitize($_POST['diagnosis']);
$treatment = sanitize($_POST['treatment'] ?? '');
$description = sanitize($_POST['description'] ?? '');

// Vérifier que le médecin a accès à ce patient
$stmt = $pdo->prepare("SELECT COUNT(*) FROM medical_records 
                      WHERE patient_id = ? AND doctor_id = ?");
$stmt->execute([$patient_id, $_SESSION['user_id']]);
$has_access = $stmt->fetchColumn();

if (!$has_access) {
    $_SESSION['error'] = "Accès non autorisé à ce dossier patient";
    header("Location: patients.php");
    exit();
}

try {
    $pdo->beginTransaction();
    
    // Récupérer le nom du médecin
    $stmt = $pdo->prepare("SELECT CONCAT(first_name, ' ', last_name) AS doctor_name 
                          FROM users 
                          WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $doctor = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Insertion du dossier médical
    $stmt = $pdo->prepare("INSERT INTO medical_records 
                          (patient_id, doctor_id, doctor_name, record_type, record_date, 
                          diagnosis, treatment, description, created_at)
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    
    $stmt->execute([
        $patient_id,
        $_SESSION['user_id'],
        $doctor['doctor_name'],
        $record_type,
        $record_date,
        $diagnosis,
        $treatment,
        $description
    ]);
    
    $record_id = $pdo->lastInsertId();
    
    // Journalisation de l'action
    log_audit($_SESSION['user_id'], 'create_medical_record', 'medical_records', $record_id);
    
    $pdo->commit();
    
    $_SESSION['success'] = "Dossier médical ajouté avec succès";
    header("Location: patient_dossier.php?patient_id=$patient_id");
    exit();
} catch (PDOException $e) {
    $pdo->rollBack();
    error_log("Erreur création dossier médical: " . $e->getMessage());
    $_SESSION['error'] = "Erreur lors de l'ajout du dossier médical: " . $e->getMessage();
    header("Location: patient_dossier.php?patient_id=$patient_id");
    exit();
}