<?php
session_start(); // Ajoutez cette ligne au tout début

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

// Vérification plus robuste
if (!isset($_SESSION['user_id']) || !check_user_type(['doctor', 'admin'])) {
    header('Location: ../login.php?error=access_denied');
    exit();
}

define('EXTRA_CSS', 'patients-enhancements.css');
define('EXTRA_JS', 'patients-enhancements.js');

$title = "Gestion des Patients";
$error = $_SESSION['error'] ?? '';
$success = $_SESSION['success'] ?? '';
unset($_SESSION['error'], $_SESSION['success']);

// Traitement du formulaire d'ajout
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_patient'])) {
    try {
        $pdo->beginTransaction();
        
        // Validation des données
        $required_fields = ['first_name', 'last_name', 'email', 'date_of_birth', 'insurance_number'];
        foreach ($required_fields as $field) {
            if (empty($_POST[$field])) {
                throw new Exception("Le champ " . str_replace('_', ' ', $field) . " est obligatoire.");
            }
        }
        
        if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
            throw new Exception("L'adresse email n'est pas valide.");
        }
        
        // Vérification si l'email existe déjà
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE email = ?");
        $stmt->execute([$_POST['email']]);
        if ($stmt->fetchColumn() > 0) {
            throw new Exception("Cette adresse email est déjà utilisée.");
        }
        
        // Création de l'utilisateur
        $stmt = $pdo->prepare("INSERT INTO users 
                             (username, email, password, user_type, first_name, last_name, date_of_birth, phone) 
                             VALUES (?, ?, ?, 'patient', ?, ?, ?, ?)");
        
        $password = password_hash(bin2hex(random_bytes(8)), PASSWORD_BCRYPT);
        $username = generate_username($_POST['first_name'], $_POST['last_name']);
        
        $stmt->execute([
            $username,
            sanitize($_POST['email']),
            $password,
            sanitize($_POST['first_name']),
            sanitize($_POST['last_name']),
            $_POST['date_of_birth'],
            sanitize($_POST['phone'] ?? null)
        ]);
        
        $user_id = $pdo->lastInsertId();
        
        // Création du dossier patient
        $stmt = $pdo->prepare("INSERT INTO patients 
                             (user_id, blood_type, allergies, insurance_number) 
                             VALUES (?, ?, ?, ?)");
        $stmt->execute([
            $user_id,
            $_POST['blood_type'] ?? null,
            sanitize($_POST['allergies'] ?? null),
            sanitize($_POST['insurance_number'])
        ]);
        
        $pdo->commit();
        
        $_SESSION['success'] = "Patient ajouté avec succès. Identifiant: $username";
        log_audit($_SESSION['user_id'], 'create_patient', 'users', $user_id);
        
        header('Location: patients.php');
        exit();
    } catch (Exception $e) {
        $pdo->rollBack();
        $error = "Erreur: " . $e->getMessage();
    }
}

// Récupération des patients avec pagination et recherche
$search = $_GET['search'] ?? '';
$current_page = max(1, $_GET['page'] ?? 1);
$per_page = 10;
$offset = ($current_page - 1) * $per_page;

$sql = "SELECT SQL_CALC_FOUND_ROWS u.id, u.first_name, u.last_name, u.email, u.phone, u.date_of_birth,
       p.blood_type, p.allergies, p.insurance_number
       FROM users u
       JOIN patients p ON u.id = p.user_id
       WHERE u.user_type = 'patient'";
$params = [];

if (!empty($search)) {
    $sql .= " AND (u.first_name LIKE ? OR u.last_name LIKE ? OR u.email LIKE ? OR p.insurance_number LIKE ?)";
    $search_term = "%$search%";
    $params = array_merge($params, [$search_term, $search_term, $search_term, $search_term]);
}

$sql .= " ORDER BY u.last_name, u.first_name
         LIMIT :offset, :per_page";

$stmt = $pdo->prepare($sql);

foreach ($params as $key => $value) {
    $stmt->bindValue($key + 1, $value);
}

$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->bindValue(':per_page', $per_page, PDO::PARAM_INT);
$stmt->execute();
$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total_patients = $pdo->query("SELECT FOUND_ROWS()")->fetchColumn();
$total_pages = ceil($total_patients / $per_page);

require_once __DIR__ . '/../includes/header_footer.php';
echo show_header($title);
?>

<div class="doctor-container patient-management-container">
    <div class="breadcrumb">
        <a href="dashboard.php">Tableau de bord</a> &gt; <span>Gestion des Patients</span>
    </div>
    
    <h1>Gestion des Patients</h1>
    
    <?php if ($error): ?>
        <div class="alert error flash-message flash-error">
            <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
        </div>
    <?php elseif ($success): ?>
        <div class="alert success flash-message flash-success">
            <i class="fas fa-check-circle"></i> <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>
    
    <div class="grid-container">
        <!-- Formulaire d'ajout -->
        <section class="add-patient-form patient-form-card">
            <h2><i class="fas fa-user-plus"></i> Ajouter un Patient</h2>
            <form id="patientForm" method="POST">
                <div class="form-row-enhanced">
                    <div class="form-group-enhanced">
                        <label>Prénom *</label>
                        <input type="text" name="first_name" required>
                    </div>
                    <div class="form-group-enhanced">
                        <label>Nom *</label>
                        <input type="text" name="last_name" required>
                    </div>
                </div>
                
                <div class="form-group-enhanced">
                    <label>Email *</label>
                    <input type="email" name="email" required>
                </div>
                
                <div class="form-group-enhanced">
                    <label>Téléphone</label>
                    <input type="text" name="phone" placeholder="+33 6 12 34 56 78">
                </div>
                
                <div class="form-group-enhanced">
                    <label>Date de Naissance *</label>
                    <input type="date" name="date_of_birth" required>
                </div>
                
                <div class="form-row-enhanced">
                    <div class="form-group-enhanced">
                        <label>Groupe Sanguin</label>
                        <select name="blood_type">
                            <option value="">Inconnu</option>
                            <option value="A+">A+</option>
                            <option value="A-">A-</option>
                            <option value="B+">B+</option>
                            <option value="B-">B-</option>
                            <option value="AB+">AB+</option>
                            <option value="AB-">AB-</option>
                            <option value="O+">O+</option>
                            <option value="O-">O-</option>
                        </select>
                    </div>
                    
                    <div class="form-group-enhanced">
                        <label>Numéro d'assurance *</label>
                        <input type="text" name="insurance_number" required>
                    </div>
                </div>
                
                <div class="form-group-enhanced">
                    <label>Allergies</label>
                    <textarea name="allergies" placeholder="Liste des allergies connues..."></textarea>
                </div>
                
                <button type="submit" name="add_patient" class="btn-submit btn-primary-enhanced">
                    <i class="fas fa-save"></i> Enregistrer
                </button>
            </form>
        </section>
        
        <!-- Liste des patients -->
        <section class="patients-list patient-list-section">
            <div class="list-header-enhanced">
                <h2><i class="fas fa-users"></i> Liste des Patients</h2>
                <div class="search-container">
                    <input type="text" id="searchInput" class="search-input-enhanced" 
                           value="<?= htmlspecialchars($search) ?>" 
                           placeholder="Rechercher un patient...">
                    <button type="button" class="search-btn-enhanced">
                        <i class="fas fa-search"></i>
                    </button>
                    <?php if (!empty($search)): ?>
                        <a href="patients.php" class="btn-clear btn-secondary-enhanced">
                            <i class="fas fa-times"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="table-responsive">
                <table id="patientsTable" class="table-enhanced">
                    <thead>
                        <tr>
                            <th><i class="fas fa-user"></i> Nom</th>
                            <th><i class="fas fa-envelope"></i> Email</th>
                            <th><i class="fas fa-phone"></i> Téléphone</th>
                            <th><i class="fas fa-birthday-cake"></i> Âge</th>
                            <th><i class="fas fa-cog"></i> Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($patients as $patient): ?>
                        <tr>
                            <td><?= htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']) ?></td>
                            <td><?= htmlspecialchars($patient['email']) ?></td>
                            <td><?= htmlspecialchars($patient['phone'] ?? 'Non renseigné') ?></td>
                            <td><?= calculateAge($patient['date_of_birth']) ?> ans</td>
                            <td class="actions">
                                <div class="action-buttons-enhanced">
                                    <a href="patient_dossier.php?patient_id=<?= $patient['id'] ?>" 
                                       class="action-btn action-btn-view" title="Dossier Patient">
                                       <i class="fas fa-folder-open"></i>
                                    </a>
                                    <a href="edit_patient.php?id=<?= $patient['id'] ?>" 
                                       class="action-btn action-btn-edit" title="Modifier">
                                       <i class="fas fa-edit"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                
                <?php if ($total_pages > 1): ?>
                <div class="pagination-enhanced">
                    <?php if ($current_page > 1): ?>
                        <a href="?page=1<?= !empty($search) ? '&search=' . urlencode($search) : '' ?>" 
                           class="pagination-link" title="Première page">
                           <i class="fas fa-angle-double-left"></i>
                        </a>
                        <a href="?page=<?= $current_page - 1 ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>" 
                           class="pagination-link" title="Page précédente">
                           <i class="fas fa-angle-left"></i>
                        </a>
                    <?php endif; ?>
                    
                    <?php 
                    $start = max(1, $current_page - 2);
                    $end = min($total_pages, $current_page + 2);
                    
                    for ($i = $start; $i <= $end; $i++): ?>
                        <a href="?page=<?= $i ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>" 
                           class="pagination-link <?= $i == $current_page ? 'active' : '' ?>">
                           <?= $i ?>
                        </a>
                    <?php endfor; ?>
                    
                    <?php if ($current_page < $total_pages): ?>
                        <a href="?page=<?= $current_page + 1 ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>" 
                           class="pagination-link" title="Page suivante">
                           <i class="fas fa-angle-right"></i>
                        </a>
                        <a href="?page=<?= $total_pages ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>" 
                           class="pagination-link" title="Dernière page">
                           <i class="fas fa-angle-double-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>
        </section>
    </div>
</div>

<?php
echo show_footer();