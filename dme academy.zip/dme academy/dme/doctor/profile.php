<?php
session_start();

// Vérification stricte de la session
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header('HTTP/1.1 403 Forbidden');
    die("Accès refusé");
}

require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

/**
 * Vérifie si l'utilisateur est connecté et est un médecin
 */
function is_doctor_authorized() {
    if (!isset($_SESSION['user_id']) || !is_numeric($_SESSION['user_id'])) {
        error_log("Tentative d'accès non autorisé - Session invalide");
        return false;
    }

    global $pdo;
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM doctors WHERE user_id = ?");
        $stmt->execute([$_SESSION['user_id']]);
        return $stmt->fetchColumn() > 0;
    } catch (PDOException $e) {
        error_log("Erreur DB vérification médecin: " . $e->getMessage());
        return false;
    }
}

// Vérification d'accès
if (!is_doctor_authorized()) {
    error_log("Tentative d'accès non autorisé par user_id: " . $_SESSION['user_id']);
    header('Location: ../login.php?error=access_denied');
    exit();
}
$user_id = (int)$_SESSION['user_id'];

// Récupération des données avec vérification
$user = get_user_by_id($user_id);
$doctor = get_doctor_by_user_id($user_id);

if (!$user || !$doctor) {
    header('HTTP/1.1 404 Not Found');
    die("Erreur: Impossible de charger les données utilisateur");
}

// Fusion des données
$doctor_data = array_merge($user, $doctor);

// Traitement du formulaire avec validation renforcée
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputs = [
        'first_name' => trim($_POST['first_name'] ?? ''),
        'last_name' => trim($_POST['last_name'] ?? ''),
        'email' => trim($_POST['email'] ?? ''),
        'phone' => trim($_POST['phone'] ?? ''),
        'specialization' => trim($_POST['specialization'] ?? ''),
        'license_number' => trim($_POST['license_number'] ?? ''),
        'hospital_affiliation' => trim($_POST['hospital_affiliation'] ?? ''),
        'bio' => trim($_POST['bio'] ?? '')
    ];

    // Validation
    $errors = [];
    if (empty($inputs['first_name']) || !preg_match('/^[a-zA-ZÀ-ÿ\s\-]{2,50}$/', $inputs['first_name'])) {
        $errors[] = "Prénom invalide (2-50 caractères alphabétiques)";
    }
    if (empty($inputs['last_name']) || !preg_match('/^[a-zA-ZÀ-ÿ\s\-]{2,50}$/', $inputs['last_name'])) {
        $errors[] = "Nom invalide (2-50 caractères alphabétiques)";
    }
    if (!filter_var($inputs['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Email invalide";
    }
    if (!empty($inputs['phone']) && !preg_match('/^[0-9\s\+\-]{10,20}$/', $inputs['phone'])) {
        $errors[] = "Format de téléphone invalide";
    }
    if (empty($inputs['license_number']) || !preg_match('/^[a-zA-Z0-9\-]{5,20}$/', $inputs['license_number'])) {
        $errors[] = "Numéro de licence invalide (5-20 caractères alphanumériques)";
    }

    if (empty($errors)) {
        try {
            // Journalisation avant modification
            log_audit($user_id, 'UPDATE', 'users', $user_id, json_encode($user), json_encode($inputs));
            log_audit($user_id, 'UPDATE', 'doctors', $user_id, json_encode($doctor), json_encode($inputs));
            
            $user_updated = update_user($user_id, [
                'first_name' => $inputs['first_name'],
                'last_name' => $inputs['last_name'],
                'email' => $inputs['email'],
                'phone' => $inputs['phone']
            ]);
            
            $doctor_updated = update_doctor($user_id, [
                'specialization' => $inputs['specialization'],
                'license_number' => $inputs['license_number'],
                'hospital_affiliation' => $inputs['hospital_affiliation'],
                'bio' => $inputs['bio']
            ]);
            
            if ($user_updated && $doctor_updated) {
                $_SESSION['success_message'] = "Profil mis à jour avec succès";
                // Recharger les données
                $user = get_user_by_id($user_id);
                $doctor = get_doctor_by_user_id($user_id);
                $doctor_data = array_merge($user, $doctor);
                header('Location: profile.php');
                exit();
            } else {
                $errors[] = "Erreur lors de la mise à jour de la base de données";
            }
        } catch (PDOException $e) {
            $errors[] = "Une erreur technique est survenue";
            error_log("Erreur mise à jour profil: " . $e->getMessage());
        }
    }
}

$page_title = "Mon Profil";
define('ACCESS_ALLOWED', true);
require_once __DIR__ . '/../includes/header_footer.php';

echo show_header($page_title);
?>

<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="../assets/css/doctor-profile.css">

<div class="doctor-profile">
  <div class="profile-container">
    <div id="toast-container"></div>
    
    <!-- Colonne Formulaire -->
    <div class="form-column">
      <div class="profile-section">
        <h1 class="profile-title">Mon Profil Médical</h1>
        
        <?php if (isset($_SESSION['success_message'])): ?>
          <div class="alert alert-success">
            <?= htmlspecialchars($_SESSION['success_message']) ?>
          </div>
          <?php unset($_SESSION['success_message']); ?>
        <?php endif; ?>
        
        <?php if (!empty($errors)): ?>
          <div class="alert alert-danger">
            <?php foreach ($errors as $error): ?>
              <p><?= htmlspecialchars($error) ?></p>
            <?php endforeach; ?>
          </div>
        <?php endif; ?>
        
        <form method="post" id="profileForm" class="form-grid">
          <div class="form-section">
            <h2 class="section-title">Informations personnelles</h2>
            <div class="form-group">
              <label for="first_name" class="form-label">Prénom *</label>
              <input type="text" class="form-control" id="first_name" name="first_name" 
                     value="<?= htmlspecialchars($doctor_data['first_name'] ?? '') ?>" required>
              <div class="invalid-feedback" id="first_name-error"></div>
            </div>
            
            <div class="form-group">
              <label for="last_name" class="form-label">Nom *</label>
              <input type="text" class="form-control" id="last_name" name="last_name" 
                     value="<?= htmlspecialchars($doctor_data['last_name'] ?? '') ?>" required>
              <div class="invalid-feedback" id="last_name-error"></div>
            </div>
            
            <div class="form-group">
              <label for="email" class="form-label">Email *</label>
              <input type="email" class="form-control" id="email" name="email" 
                     value="<?= htmlspecialchars($doctor_data['email'] ?? '') ?>" required>
              <div class="invalid-feedback" id="email-error"></div>
            </div>
            
            <div class="form-group">
              <label for="phone" class="form-label">Téléphone</label>
              <input type="tel" class="form-control" id="phone" name="phone" 
                     value="<?= htmlspecialchars($doctor_data['phone'] ?? '') ?>">
              <div class="invalid-feedback" id="phone-error"></div>
            </div>
          </div>

          <div class="form-section">
            <h2 class="section-title">Informations professionnelles</h2>
            <div class="form-group">
              <label for="license_number" class="form-label">Numéro de licence *</label>
              <input type="text" class="form-control" id="license_number" name="license_number" 
                     value="<?= htmlspecialchars($doctor_data['license_number'] ?? '') ?>" required>
              <div class="invalid-feedback" id="license_number-error"></div>
            </div>
            
            <div class="form-group">
              <label for="specialization" class="form-label">Spécialisation</label>
              <input type="text" class="form-control" id="specialization" name="specialization" 
                     value="<?= htmlspecialchars($doctor_data['specialization'] ?? '') ?>">
            </div>
            
            <div class="form-group">
              <label for="hospital_affiliation" class="form-label">Établissement hospitalier</label>
              <input type="text" class="form-control" id="hospital_affiliation" name="hospital_affiliation" 
                     value="<?= htmlspecialchars($doctor_data['hospital_affiliation'] ?? '') ?>">
            </div>
            
            <div class="form-group">
              <label for="bio" class="form-label">Biographie</label>
              <textarea class="form-control" id="bio" name="bio" rows="4"><?= htmlspecialchars($doctor_data['bio'] ?? '') ?></textarea>
              <div class="char-counter" id="bio-counter"></div>
            </div>
          </div>
          
          <button type="submit" class="btn btn-primary">
            <span class="btn-text">Mettre à jour</span>
            <span class="spinner" style="display: none;"></span>
          </button>
        </form>
      </div>
    </div>

    <!-- Colonne Aperçu -->
    <div class="preview-column">
      <div class="profile-section">
        <h2 class="section-title">Aperçu du Profil</h2>
        
        <div class="preview-section">
          <h3 class="preview-subtitle">Informations personnelles</h3>
          <div class="preview-grid">
            <div class="preview-item">
              <span class="preview-label">Nom complet:</span>
              <span class="preview-value" id="preview-fullname"><?= htmlspecialchars($doctor_data['first_name'] . ' ' . $doctor_data['last_name']) ?></span>
            </div>
            <div class="preview-item">
              <span class="preview-label">Email:</span>
              <span class="preview-value" id="preview-email"><?= htmlspecialchars($doctor_data['email']) ?></span>
            </div>
            <div class="preview-item">
              <span class="preview-label">Téléphone:</span>
              <span class="preview-value" id="preview-phone"><?= !empty($doctor_data['phone']) ? htmlspecialchars($doctor_data['phone']) : 'Non renseigné' ?></span>
            </div>
          </div>
        </div>
        
        <div class="preview-section">
          <h3 class="preview-subtitle">Informations professionnelles</h3>
          <div class="preview-grid">
            <div class="preview-item">
              <span class="preview-label">Numéro de licence:</span>
              <span class="preview-value" id="preview-license"><?= htmlspecialchars($doctor_data['license_number'] ?? 'Non renseigné') ?></span>
            </div>
            <div class="preview-item">
              <span class="preview-label">Spécialisation:</span>
              <span class="preview-value" id="preview-specialization"><?= !empty($doctor_data['specialization']) ? htmlspecialchars($doctor_data['specialization']) : 'Non renseignée' ?></span>
            </div>
            <div class="preview-item">
              <span class="preview-label">Établissement:</span>
              <span class="preview-value" id="preview-hospital"><?= !empty($doctor_data['hospital_affiliation']) ? htmlspecialchars($doctor_data['hospital_affiliation']) : 'Non renseigné' ?></span>
            </div>
            <div class="preview-item preview-bio">
              <span class="preview-label">Biographie:</span>
              <div class="preview-value" id="preview-bio"><?= !empty($doctor_data['bio']) ? nl2br(htmlspecialchars($doctor_data['bio'])) : 'Aucune biographie renseignée' ?></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/imask"></script>
<script src="../assets/js/doctor-profile.js"></script>

<?php
echo show_footer();
?>