<?php
// logout.php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/functions.php'; // Cette inclusion était manquante

// Journalisation de la déconnexion (si utilisateur connecté)
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    
    // Vérifie si la fonction existe avant de l'appeler
    if (function_exists('log_audit')) {
        log_audit($user_id, 'logout', 'session', null, 'User logged out', null);
    } else {
        error_log("Audit: User $user_id logged out (log_audit function missing)");
    }
}

// Destruction sécurisée de la session
$_SESSION = array();

// Suppression du cookie de session
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

// Destruction finale
session_destroy();

// Redirection vers la page de login avec anti-caching
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Location: login.php");
exit();