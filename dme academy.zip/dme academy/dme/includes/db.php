<?php
$host = 'localhost';
$dbname = 'dme';         // Le vrai nom de ta base (à vérifier dans phpMyAdmin ou MySQL)
$username = 'root';      // En local c'est souvent 'root'
$password = '';          // En local souvent aucun mot de passe (juste vide '')

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données: " . $e->getMessage());
}
