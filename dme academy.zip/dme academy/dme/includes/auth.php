<?php
// Démarrage de la session si pas encore active
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Fonction : vérifier si la session est active
function verify_session() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: /login.php?error=session_expired');
        exit();
    }
}

// Fonction : vérifier le type d'utilisateur (ex: 'doctor' ou 'patient')
function verify_user_type($required_type) {
    if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== $required_type) {
        error_log("Tentative d'accès non autorisé - Mauvais type utilisateur");
        header('Location: /unauthorized.php');
        exit();
    }
}
