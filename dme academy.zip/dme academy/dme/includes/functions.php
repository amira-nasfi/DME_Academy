<?php
// includes/functions.php

require_once 'db.php';

// --- Fonctions de sécurité ---
function sanitize_input($data) {
    if (is_array($data)) {
        return array_map('sanitize_input', $data);
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// --- AUDIT LOGGING POUR HIPAA ---
function log_audit($user_id, $action, $table_affected, $record_id = null, $old_value = null, $new_value = null) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("INSERT INTO audit_logs 
            (user_id, action, table_affected, record_id, old_value, new_value, ip_address, user_agent) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        
        $ip_address = $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN';
        $user_agent = substr($_SERVER['HTTP_USER_AGENT'] ?? 'UNKNOWN', 0, 255);
        
        $stmt->execute([
            (int)$user_id,
            substr($action, 0, 50),
            substr($table_affected, 0, 50),
            $record_id,
            is_string($old_value) ? substr($old_value, 0, 1000) : json_encode($old_value),
            is_string($new_value) ? substr($new_value, 0, 1000) : json_encode($new_value),
            $ip_address,
            $user_agent
        ]);
        return true;
    } catch (PDOException $e) {
        error_log("Erreur d'audit : " . $e->getMessage());
        return false;
    }
}

// --- GESTION DES UTILISATEURS ---
function get_user_by_id($user_id) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
        $stmt->execute([(int)$user_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Erreur get_user_by_id: " . $e->getMessage());
        return false;
    }
}

function get_doctor_by_user_id($user_id) {
    global $pdo;
    
    // Validation de l'input
    if (!is_numeric($user_id)) {
        error_log("ID utilisateur invalide: " . $user_id);
        return false;
    }

    try {
        $stmt = $pdo->prepare("SELECT * FROM doctors WHERE user_id = ? LIMIT 1");
        $stmt->execute([$user_id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$result) {
            error_log("Aucun médecin trouvé pour user_id: " . $user_id);
        }
        
        return $result;
    } catch (PDOException $e) {
        error_log("Erreur DB get_doctor_by_user_id: " . $e->getMessage());
        return false;
    }
}
function update_user($user_id, $data) {
    global $pdo;
    
    if (!is_array($data) || empty($data)) {
        return false;
    }
    
    try {
        $setParts = [];
        $values = [];
        $allowed_fields = ['first_name', 'last_name', 'email', 'phone'];
        
        foreach ($data as $key => $value) {
            if (in_array($key, $allowed_fields)) {
                $setParts[] = "$key = ?";
                $values[] = $value;
            }
        }
        
        if (empty($setParts)) {
            return false;
        }
        
        $values[] = (int)$user_id;
        
        $stmt = $pdo->prepare("UPDATE users SET " . implode(', ', $setParts) . " WHERE id = ?");
        return $stmt->execute($values);
    } catch (PDOException $e) {
        error_log("Erreur update_user: " . $e->getMessage());
        return false;
    }
}

function update_doctor($user_id, $data) {
    global $pdo;
    
    if (!is_array($data) || empty($data)) {
        return false;
    }
    
    try {
        $setParts = [];
        $values = [];
        $allowed_fields = ['specialization', 'license_number', 'hospital_affiliation', 'bio'];
        
        foreach ($data as $key => $value) {
            if (in_array($key, $allowed_fields)) {
                $setParts[] = "$key = ?";
                $values[] = $value;
            }
        }
        
        if (empty($setParts)) {
            return false;
        }
        
        $values[] = (int)$user_id;
        
        $stmt = $pdo->prepare("UPDATE doctors SET " . implode(', ', $setParts) . " WHERE user_id = ?");
        return $stmt->execute($values);
    } catch (PDOException $e) {
        error_log("Erreur update_doctor: " . $e->getMessage());
        return false;
    }
}

// --- GÉNÉRATION DE MESSAGES HL7 ---
function generate_hl7_message($patient_id, $doctor_id, $record_type, $diagnosis_code, $diagnosis_description, $treatment) {
    $message = "MSH|^~\&|DME|HOSPITAL|HL7|HOSPITAL|" . date('YmdHis') . "||ORU^R01|" . uniqid() . "|P|2.5.1\r";
    $message .= "PID|||" . $patient_id . "|||PATIENT|||||||||||||||||\r";
    $message .= "PV1||I|LOCATION||||" . $doctor_id . "^DOCTOR|||||||||||||||||\r";
    $message .= "OBR|1|||" . $record_type . "|||||||||||||||||||||||||||||||||||||\r";
    $message .= "OBX|1|CE|" . $diagnosis_code . "||" . $diagnosis_description . "||||||F\r";
    $message .= "OBX|2|TX|TREATMENT||" . $treatment . "||||||F\r";
    
    return $message;
}

// --- VALIDATION HL7 ---
function validate_hl7_data($data) {
    $errors = [];
    if (empty($data['diagnosis_code'])) {
        $errors[] = "Le code de diagnostic est requis (ICD-10)";
    }
    if (empty($data['diagnosis_description'])) {
        $errors[] = "La description du diagnostic est requise";
    }
    return $errors;
}

// --- PERMISSIONS HIPAA ---
function check_hippa_permissions($user_type, $action, $data_type) {
    $permissions = [
        'doctor' => [
            'view' => ['patient', 'medical_record', 'prescription'],
            'create' => ['medical_record', 'prescription'],
            'edit' => ['medical_record', 'prescription'],
            'delete' => []
        ],
        'patient' => [
            'view' => ['own_record', 'own_prescription'],
            'create' => [],
            'edit' => ['profile'],
            'delete' => []
        ]
    ];
    return isset($permissions[$user_type][$action]) && in_array($data_type, $permissions[$user_type][$action]);
}

// --- VÉRIFICATION ACCÈS DOSSIERS MÉDICAUX ---
function check_medical_record_access($record_id, $user_id, $user_type) {
    global $pdo;
    
    if ($user_type === 'doctor') {
        $stmt = $pdo->prepare("SELECT id FROM medical_records WHERE id = ? AND doctor_id = ?");
        $stmt->execute([$record_id, $user_id]);
    } else {
        $stmt = $pdo->prepare("SELECT id FROM medical_records WHERE id = ? AND patient_id = ?");
        $stmt->execute([$record_id, $user_id]);
    }
    
    return $stmt->fetch() !== false;
}

// --- RÉCUPÉRATION D'UN DOSSIER MÉDICAL ---
function get_medical_record($id, $doctor_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM medical_records WHERE id = ? AND doctor_id = ?");
    $stmt->execute([$id, $doctor_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// --- VÉRIFIER SI DOCTEUR A ACCÈS AU PATIENT ---
function has_access_to_patient($doctor_id, $patient_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT 1 FROM medical_records WHERE doctor_id = ? AND patient_id = ? LIMIT 1");
    $stmt->execute([$doctor_id, $patient_id]);
    return (bool)$stmt->fetch();
}

// --- GÉNÉRATION DE PDF (EXEMPLE) ---
function generate_medical_pdf($record_id) {
    return "PDF generated for record $record_id"; // À remplacer par TCPDF, FPDF etc.
}

// --- NOUVELLE FONCTION HL7 ---
function create_hl7_message($patient_id, $doctor_id, $message_type, $content) {
    $hl7 = [
        "MSH|^~\&|DME|SERVER|HL7|FACILITY|" . date('YmdHis') . "||" . $message_type . "|" . uniqid() . "|P|2.5.1",
        "PID|||$patient_id|||||||",
        "PV1||I||||||$doctor_id^DOCTOR|||||||||||||||||||||||||||||||||||||||||",
        "OBX|1|TX|$message_type||" . str_replace("\n", "\\n", $content) . "||||||F"
    ];
    return implode("\n", $hl7);
}

// ==============================
// SECTION : GESTION DES RENDEZ-VOUS
// ==============================

// Récupérer les RDV d'un patient
function getPatientAppointments($patient_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT a.*, 
               a.date AS appointment_date,
               a.time AS appointment_time,
               d.license_number AS doctor_license_number, 
               d.specialization AS doctor_specialization
        FROM appointments a
        JOIN doctors d ON a.doctor_id = d.user_id
        WHERE a.patient_id = ?
        ORDER BY a.date DESC, a.time DESC
    ");
    $stmt->execute([$patient_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Récupérer les RDV d'un docteur
function getDoctorAppointments($doctor_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT a.*, 
               CONCAT(u.first_name, ' ', u.last_name) AS patient_name,
               a.date AS appointment_date,
               a.time AS appointment_time,
               p.insurance_number AS patient_insurance_number,
               p.blood_type AS patient_blood_type
        FROM appointments a
        JOIN users u ON a.patient_id = u.id
        LEFT JOIN patients p ON u.id = p.user_id
        WHERE a.doctor_id = ?
        ORDER BY a.date DESC, a.time DESC
    ");
    $stmt->execute([$doctor_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Créer un RDV
function getDoctorAppointmentsWithDetails($doctor_id) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        SELECT a.*, 
               CONCAT(u.first_name, ' ', u.last_name) AS patient_name,
               CONCAT(a.date, ' ', a.time) AS appointment_datetime
        FROM appointments a
        JOIN users u ON a.patient_id = u.id
        WHERE a.doctor_id = ? 
        ORDER BY a.date DESC, a.time DESC
    ");
    $stmt->execute([$doctor_id]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Mettre à jour le statut d'un RDV
function updateAppointmentStatus($appointment_id, $status) {
    global $pdo;
    
    $stmt = $pdo->prepare("
        UPDATE appointments 
        SET status = ?
        WHERE id = ?
    ");
    
    return $stmt->execute([$status, $appointment_id]);
}

// Formatter date + heure RDV
// Removed duplicate function declaration to avoid redeclaration error.

// --- Récupérer tous les patients ---
function getAllPatients() {
    global $pdo;
    $stmt = $pdo->query("
        SELECT u.id, u.first_name, u.last_name, p.insurance_number, p.blood_type 
        FROM users u
        JOIN patients p ON u.id = p.user_id
        WHERE u.user_type = 'patient'
    ");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// --- Récupérer tous les docteurs ---
function getAllDoctors() {
    global $pdo;
    $stmt = $pdo->query("
        SELECT u.id, u.first_name, u.last_name, d.license_number, d.specialization 
        FROM users u
        JOIN doctors d ON u.id = d.user_id
        WHERE u.user_type = 'doctor'
    ");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// --- Récupérer les infos complètes d'un patient ---
function get_patient_details($patient_id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT u.*, p.* FROM users u JOIN patients p ON u.id = p.user_id WHERE u.id = ?");
    $stmt->execute([$patient_id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// --- Calculer l'âge ---
function calculateAge($birthdate) {
    if (empty($birthdate)) return 'Inconnu';
    $birth = new DateTime($birthdate);
    $now = new DateTime();
    return $now->diff($birth)->y;
}

// --- Créer un rendez-vous ---
function createAppointment($patient_id, $doctor_id, $date, $time, $reason) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("
            INSERT INTO appointments 
            (patient_id, doctor_id, date, time, reason, status, created_at) 
            VALUES (?, ?, ?, ?, ?, 'scheduled', NOW())
        ");
        
        return $stmt->execute([$patient_id, $doctor_id, $date, $time, $reason]);
    } catch (PDOException $e) {
        error_log("Erreur création rendez-vous: " . $e->getMessage());
        return false;
    }
}
function log_activity(string $action): void {
    $log = sprintf(
        "[%s] %s - %s - %s\n",
        date('Y-m-d H:i:s'),
        $_SERVER['REMOTE_ADDR'],
        $_SESSION['user_id'] ?? 'guest',
        $action
    );
    file_put_contents(__DIR__.'/../logs/activity.log', $log, FILE_APPEND);
}
// Ajoutez cette fonction dans includes/functions.php
function formatDate($dateString, $format = 'd/m/Y') {
    if (empty($dateString) || $dateString == '0000-00-00') {
        return 'N/A';
    }
    try {
        $date = new DateTime($dateString);
        return $date->format($format);
    } catch (Exception $e) {
        error_log("Erreur formatDate: " . $e->getMessage());
        return $dateString; // Retourne la valeur originale en cas d'erreur
    }
}

// Fonction pour formater la date et l'heure
function formatDateTime($dateString, $timeString = '', $format = 'd/m/Y H:i') {
    if (empty($dateString)) {
        return 'N/A';
    }
    
    try {
        $datetime = new DateTime($dateString . ' ' . $timeString);
        return $datetime->format($format);
    } catch (Exception $e) {
        error_log("Erreur formatDateTime: " . $e->getMessage());
        return $dateString . ' ' . $timeString;
    }
}