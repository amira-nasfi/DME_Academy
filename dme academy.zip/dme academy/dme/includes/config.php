<?php
if (!defined('ACCESS_ALLOWED')) {
    define('ACCESS_ALLOWED', true);
}

// Configuration de la base de données
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'DME');

// Configuration de l'application
define('APP_NAME', 'DME - Dossier Médical Électronique');
define('APP_VERSION', '1.0.0');


// Configuration de sécurité
define('PEPPER', 'votre_pepper_secret_ici');
define('SESSION_TIMEOUT', 1800); // 30 minutes en secondes

// Connexion à la base de données
try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4", DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch (PDOException $e) {
    die("Erreur de connexion à la base de données: " . $e->getMessage());
}

// Démarrer la session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Fonction de protection contre les attaques XSS
function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Fonction pour vérifier si l'utilisateur est connecté
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// Fonction pour rediriger les utilisateurs non connectés
function require_login() {
    if (!is_logged_in()) {
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        header('Location: login.php');
        exit();
    }
}

// Fonction pour vérifier le type d'utilisateur
function check_user_type($allowed_types) {
    if (!in_array($_SESSION['user_type'], (array)$allowed_types)) {
        header('HTTP/1.0 403 Forbidden');
        die("Accès refusé. Vous n'avez pas les permissions nécessaires.");
    }
}
?>