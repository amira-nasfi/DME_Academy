<?php 
if (!defined('ACCESS_ALLOWED') || !constant('ACCESS_ALLOWED')) {
    die('Accès direct non autorisé');
}

// S'assurer que BASE_URL et APP_NAME sont définis
require_once __DIR__ . '/config.php';

function show_header($title = '') {
    ob_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title ? $title . ' - ' . APP_NAME : APP_NAME) ?></title>
    
    <!-- CSS Principal -->
    <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">

    <!-- CSS Supplémentaire si défini -->
    <?php if (defined('EXTRA_CSS')): ?>
        <link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/<?= EXTRA_CSS ?>">
    <?php endif; ?>

    <!-- Icônes Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
<header class="dashboard-header">
    <div class="header-left">
        <img src="<?= BASE_URL ?>/assets/images/logo.png" alt="Logo DME" class="logo-small">
        <h1><?= htmlspecialchars($_SESSION['user_type'] === 'doctor' ? 'Médecin' : 'Patient') ?></h1>
    </div>
    <div class="header-right">
        <span class="welcome-message">Bonjour, <?= htmlspecialchars($_SESSION['first_name'] ?? '') ?></span>
        <a href="<?= BASE_URL ?>/logout.php" class="btn btn-logout">Déconnexion</a>
    </div>
</header>

<nav class="main-nav">
    <ul>
        <?php if ($_SESSION['user_type'] === 'doctor'): ?>
            <li><a href="<?= BASE_URL ?>/doctor/dashboard.php">Accueil</a></li>
            <li><a href="<?= BASE_URL ?>/doctor/patients.php">Patients</a></li>
            <li><a href="<?= BASE_URL ?>/doctor/appointments.php">Rendez-vous</a></li>
            <li><a href="<?= BASE_URL ?>/doctor/profile.php" class="nav-link">Profil</a></li>
        <?php else: ?>
            <li><a href="<?= BASE_URL ?>/patient/dashboard.php">Accueil</a></li>
            <li><a href="<?= BASE_URL ?>/patient/appointments.php">Mes Rendez-vous</a></li>
        <?php endif; ?>
    </ul>
</nav>

<main class="container">
<?php
    return ob_get_clean();
}

function show_footer() {
    ob_start();
?>
</main>

<footer class="main-footer">
    <p>Système <?= APP_NAME ?> - <?= date('Y') ?></p>
</footer>

<!-- JS Principal -->
<script src="<?= BASE_URL ?>/assets/js/script.js"></script>

<!-- JS Supplémentaire si défini -->
<?php if (defined('EXTRA_JS')): ?>
    <script src="<?= BASE_URL ?>/assets/js/<?= EXTRA_JS ?>"></script>
<?php endif; ?>

</body>
</html>
<?php
    return ob_get_clean();
}
?>
