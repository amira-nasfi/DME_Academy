<?php
// forgot-password.php
require_once 'includes/config.php';

// Rediriger si déjà connecté
if (is_logged_in()) {
    redirect_to_dashboard();
}

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitize($_POST['email']);
    
    try {
        // Vérifier si l'email existe
        $stmt = $pdo->prepare("SELECT id, username FROM users WHERE email = ? LIMIT 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            // Générer un token de réinitialisation
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            // Mettre à jour l'utilisateur
            $stmt = $pdo->prepare("UPDATE users SET password_reset_token = ?, password_reset_expires = ? WHERE id = ?");
            $stmt->execute([$token, $expires, $user['id']]);
            
            // Journalisation
            log_audit($user['id'], 'password_reset_request', 'users', $user['id'], null, null);
            
            // Envoyer un email (à implémenter)
            // send_password_reset_email($email, $token);
            
            $success = "Un email de réinitialisation a été envoyé à votre adresse.";
        } else {
            $error = "Aucun compte trouvé avec cette adresse email.";
        }
    } catch (PDOException $e) {
        $error = "Erreur lors du traitement de votre demande: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mot de passe oublié - <?= APP_NAME ?></title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <img src="assets/images/logo.png" alt="Logo DME" class="logo">
            <h1>Réinitialisation du mot de passe</h1>
            <p>Entrez votre email pour recevoir un lien de réinitialisation</p>
        </div>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>
        
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?= $success ?></div>
        <?php endif; ?>
        
        <form action="forgot-password.php" method="POST" class="login-form">
            <div class="form-group">
                <label for="email">Adresse email</label>
                <input type="email" id="email" name="email" required>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Envoyer le lien</button>
            </div>
        </form>
        
        <div class="login-footer">
            <p><a href="login.php">Retour à la connexion</a></p>
        </div>
    </div>
    
    <script src="assets/js/script.js"></script>
</body>
</html>